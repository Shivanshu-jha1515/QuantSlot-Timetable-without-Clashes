# QuantSlot: Quantum-Inspired Educational Timetable Optimizer

> **"From 18 clashes to zero, in seconds."**
> 
> **Designed & Developed solely by Shivanshu Jha**

QuantSlot is a production-grade, quantum-inspired timetable scheduling platform designed for schools, colleges, and universities. By mapping scheduling constraints (instructors, rooms, and student cohorts) to a Quadratic Unconstrained Binary Optimization (QUBO) Hamiltonian, QuantSlot leverages simulated quantum annealing to find global ground states and eliminate schedule collisions in milliseconds.

---

## ⚡ Tech Stack

- **Backend**: Python 3.10+ / 3.14, FastAPI, Pydantic v2, Uvicorn
- **Solvers**:
  - `dimod` + `dwave-neal` (D-Wave Systems Simulated Annealing Sampler)
  - Pure-Python adaptive Metropolis-Hastings simulated annealer (zero-dependency fallback with guaranteed 0-clash convergence)
- **Frontend**: React 19, Vite 6, Tailwind CSS v3, Lucide Icons, Canvas Confetti

---

## 📂 Project Structure

```
QuantSlot/
├── backend/
│   ├── main.py               # FastAPI application with REST endpoints & CORS
│   ├── timetable_qubo.py     # QUBO formulation (H1, H2, H3) & dual solvers
│   ├── sample_classes.csv    # 30-class college benchmark dataset (12 slots)
│   └── requirements.txt      # Python dependencies (fastapi, dimod, dwave-neal, etc.)
├── frontend/
│   ├── index.html            # HTML entry point with dark-mode class support
│   ├── package.json          # Frontend dependencies (React 19, Tailwind, Vite)
│   ├── vite.config.js        # Vite config with backend proxy (/api -> :8000)
│   ├── tailwind.config.js    # Tailwind styling with dark blue & teal palette
│   └── src/
│       ├── main.jsx          # React DOM entry
│       ├── App.jsx           # Root router, dark mode manager, backend health checker
│       ├── index.css         # Tailwind base styles and custom glow effects
│       ├── components/
│       │   ├── Navbar.jsx           # Responsive header, theme switch, health badge
│       │   ├── Footer.jsx           # Branding, Hamiltonian terms, links
│       │   ├── ResultsCounter.jsx   # Animated 18 -> 0 counter, KPI cards, confetti
│       │   ├── TimetableGrid.jsx    # Days x Periods matrix with conflict highlighting
│       │   ├── ClassTable.jsx       # Editable table with add/edit/delete/search
│       │   ├── WeightsSliders.jsx   # Sliders for WA, WB, WC, slots, reads, solver
│       │   ├── AlgorithmDiagram.jsx # 5-step visual QUBO pipeline with formulas
│       │   └── SkeletonLoader.jsx   # Loading skeletons & pulse animations
│       ├── pages/
│       │   ├── LandingPage.jsx      # Hero, tagline, problem/solution, 3-step strip
│       │   ├── DemoPage.jsx         # Interactive optimizer with full timetable view
│       │   ├── HowItWorksPage.jsx   # QUBO math, binary variables, comparisons
│       │   └── AboutPage.jsx        # Project story, tech stack, future scope, team
│       └── services/
│           └── api.js               # API service and CSV export generator
├── sample_classes.csv        # Root copy of sample classes
├── requirements.txt          # Root copy of backend requirements
└── README.md                 # Complete setup guide for Visual Studio Code
```

---

## 🚀 Setup Steps for Visual Studio Code

### Prerequisites
1. **Python 3.10+** (Python 3.12, 3.13, or 3.14)
2. **Node.js 18+** and **npm**

---

### Step 1: Open Project in VS Code
Open the `QuantSlot` folder in Visual Studio Code:
```bash
code QuantSlot
```

---

### Step 2: Start the Backend (FastAPI)

1. Open a new terminal in VS Code (`Ctrl + ~` or Terminal > New Terminal).
2. Navigate to `backend`:
   ```bash
   cd backend
   ```
3. (Optional but recommended) Create and activate a virtual environment:
   - **Windows (PowerShell)**:
     ```powershell
     python -m venv venv
     .\venv\Scripts\Activate.ps1
     ```
   - **macOS / Linux**:
     ```bash
     python3 -m venv venv
     source venv/bin/activate
     ```
4. Install backend dependencies:
   ```bash
   pip install -r requirements.txt
   ```
5. Run the FastAPI development server:
   ```bash
   uvicorn main:app --reload --host 127.0.0.1 --port 8000
   ```
6. The backend will be live at:
   - API Root: `http://127.0.0.1:8000`
   - Interactive Swagger Docs: `http://127.0.0.1:8000/docs`

---

### Step 3: Start the Frontend (React + Vite)

1. Open a **second** terminal tab in VS Code (`Ctrl + Shift + 5` or the `+` button in the terminal panel).
2. Navigate to `frontend`:
   ```bash
   cd frontend
   ```
3. Install frontend npm dependencies:
   ```bash
   npm install
   ```
4. Start Vite development server:
   ```bash
   npm run dev
   ```
5. Open your browser and navigate to:
   ```
   http://localhost:5173
   ```

---

## 🔬 Mathematical QUBO Formulation

QuantSlot translates educational timetabling into minimizing the objective Hamiltonian:

$$\min_{x} H(x) = W_A \cdot H_1 + W_B \cdot H_2 + W_C \cdot H_3$$

Where $x_{c, s} \in \{0, 1\}$ is a binary variable indicating if course $c$ is assigned to slot $s$.

1. **$H_1$: One Slot Per Class (Hard Constraint)**
   $$\sum_{c} \left( \sum_{s} x_{c, s} - 1 \right)^2$$
   Guarantees that every course is scheduled exactly once.

2. **$H_2$: Zero Resource Conflicts (Hard Constraint)**
   $$\sum_{c_1 < c_2, s} \text{clash\_count}(c_1, c_2) \cdot x_{c_1, s} \cdot x_{c_2, s}$$
   Penalizes simultaneous assignments sharing an instructor, a classroom, or a student cohort.

3. **$H_3$: Soft Slot Preferences (Soft Constraint)**
   $$\sum_{c, s} P_{c, s} \cdot x_{c, s}$$
   Prioritizes favorable time distributions and respects preferred class periods.

---

## 🔌 API Endpoints Reference

- `POST /api/optimize`: Accepts `{ classes, slots, weights: {A, B, C}, reads, force_solver }` and returns `{ assignment, clashes_before, clashes_after, solve_time_ms, solver_used, clash_details_before, clash_details_after }`.
- `GET /api/sample`: Returns the 30-class, 12-slot benchmark dataset.
- `POST /api/upload`: Accepts a CSV file (`id, name, teacher, group, room`) and returns parsed classes.
- `GET /api/health`: Health status and solver availability check.

---

## 🏆 Key Features Demonstrated

- **From 18 Clashes to 0**: Starts from a realistic draft schedule with 18 clashes and solves down to zero in milliseconds.
- **Before vs After Inspection**: Toggle between "Before" (18 clashes highlighted in red) and "Optimized" (clean green conflict-free view).
- **Interactive Conflict Highlighting**: Explains the exact resource reasons behind any schedule collision.
- **Dynamic CSV Ingestion & Export**: Upload your own courses and download the optimized schedule with one click.
- **Dual Solver Architecture**: Employs `dwave-neal` when installed with automated fallback to the custom pure-Python annealer.

---

## 👨‍💻 Project Author & Creator

**Shivanshu Jha** — Sole Creator, System Architect & Quantum Software Engineer.
- Conceived the educational timetable Hamiltonian QUBO formulation ($H_1, H_2, H_3$).
- Designed the dual-solver annealing architecture (D-Wave Neal + pure-Python annealer).
- Implemented the full-stack system: async FastAPI REST server and reactive React 19 / Tailwind CSS application.

