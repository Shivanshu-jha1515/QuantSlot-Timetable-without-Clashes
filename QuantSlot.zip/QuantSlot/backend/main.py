"""
main.py - FastAPI Application for QuantSlot Quantum-Inspired Timetable Optimizer.
"""

from __future__ import annotations
import csv
import io
import os
from typing import Any, Dict, List, Optional
from fastapi import FastAPI, File, HTTPException, UploadFile, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from timetable_qubo import optimize_timetable, HAS_DWAVE

app = FastAPI(
    title="QuantSlot API",
    description="Quantum-Inspired Timetable Optimizer API using QUBO and Simulated Annealing",
    version="1.0.0",
)

# Enable CORS for frontend applications (Vite default 5173, 3000, etc.)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class ClassItem(BaseModel):
    id: str = Field(..., description="Unique identifier for the class or lecture session")
    name: str = Field(..., description="Name or course title of the class")
    teacher: str = Field(..., description="Teacher / instructor name")
    group: str = Field(..., description="Student cohort or group")
    room: str = Field(..., description="Assigned or designated classroom/lab")
    preferred_slot: Optional[int] = Field(None, description="Optional preferred slot (0-indexed)")
    slot: Optional[int] = Field(None, description="Pre-assigned slot if any")


class Weights(BaseModel):
    A: float = Field(10.0, description="Penalty weight for H1 (each class exactly one slot)")
    B: float = Field(15.0, description="Penalty weight for H2 (no teacher/room/group clash)")
    C: float = Field(1.0, description="Weight for H3 (soft slot preferences)")


class OptimizeRequest(BaseModel):
    classes: List[ClassItem] = Field(..., min_length=1, description="List of classes to schedule")
    slots: int = Field(12, ge=1, le=100, description="Total number of available time slots")
    weights: Optional[Weights] = Field(default_factory=Weights, description="QUBO objective weights")
    reads: Optional[int] = Field(100, ge=10, le=1000, description="Number of annealing reads")
    force_solver: Optional[str] = Field(None, description="Optional solver override ('dwave' or 'pure-python')")


class OptimizeResponse(BaseModel):
    assignment: List[Dict[str, Any]]
    clashes_before: int
    clashes_after: int
    solve_time_ms: float
    solver_used: str
    clash_details_before: Optional[List[Dict[str, Any]]] = None
    clash_details_after: Optional[List[Dict[str, Any]]] = None
    qubo_vars: int
    energy: float


@app.get("/")
def root():
    return {
        "app": "QuantSlot API",
        "status": "operational",
        "tagline": "From 18 clashes to zero, in seconds.",
        "dwave_installed": HAS_DWAVE,
        "docs_url": "/docs"
    }


@app.get("/api/health")
def health_check():
    return {
        "status": "healthy",
        "dwave_neal_available": HAS_DWAVE,
        "pure_python_fallback": True
    }


@app.get("/api/sample")
def get_sample_dataset():
    """
    Returns the standard benchmark dataset (30 classes, 12 slots).
    """
    csv_path = os.path.join(os.path.dirname(__file__), "sample_classes.csv")
    if not os.path.exists(csv_path):
        # Fallback to root sample_classes.csv if backend directory was relative
        csv_path = os.path.join(os.path.dirname(__file__), "..", "sample_classes.csv")

    classes = []
    if os.path.exists(csv_path):
        with open(csv_path, mode="r", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            for row in reader:
                classes.append({
                    "id": row.get("id", "").strip(),
                    "name": row.get("name", "").strip(),
                    "teacher": row.get("teacher", "").strip(),
                    "group": row.get("group", "").strip(),
                    "room": row.get("room", "").strip(),
                })
    else:
        raise HTTPException(status_code=404, detail="Sample dataset file not found")

    return {
        "classes": classes,
        "slots": 12,
        "weights": {"A": 10.0, "B": 15.0, "C": 1.0},
        "reads": 100,
        "description": "Benchmark dataset consisting of 30 classes across 8 teachers, 6 student groups, and 5 rooms."
    }


@app.post("/api/upload")
async def upload_csv(file: UploadFile = File(...)):
    """
    Accepts a CSV file containing (id, name, teacher, group, room) and returns parsed classes.
    """
    if not file.filename.lower().endswith(".csv"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Uploaded file must be a .csv file"
        )

    try:
        content = await file.read()
        text_content = content.decode("utf-8-sig")
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to read CSV content: {str(e)}"
        )

    try:
        reader = csv.DictReader(io.StringIO(text_content))
        # Validate columns
        if not reader.fieldnames:
            raise HTTPException(status_code=400, detail="CSV file appears to be empty or has no header.")

        # Normalize field names (case-insensitive, trimmed)
        field_map = {fn.strip().lower(): fn for fn in reader.fieldnames}
        required_fields = ["id", "name", "teacher", "group", "room"]
        missing = [rf for rf in required_fields if rf not in field_map]
        if missing:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"CSV missing required columns: {', '.join(missing)}. Required: id, name, teacher, group, room"
            )

        classes = []
        for line_num, row in enumerate(reader, start=2):
            cid = str(row[field_map["id"]]).strip()
            name = str(row[field_map["name"]]).strip()
            teacher = str(row[field_map["teacher"]]).strip()
            group = str(row[field_map["group"]]).strip()
            room = str(row[field_map["room"]]).strip()

            if not cid and not name:
                continue

            classes.append({
                "id": cid or f"CLS_{line_num}",
                "name": name or f"Subject {line_num}",
                "teacher": teacher or "Unassigned",
                "group": group or "General",
                "room": room or "Room-101",
            })

        if not classes:
            raise HTTPException(status_code=400, detail="No valid class rows found in CSV.")

        return {
            "classes": classes,
            "count": len(classes),
            "message": f"Successfully parsed {len(classes)} classes from {file.filename}"
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Failed to parse CSV: {str(e)}"
        )


@app.post("/api/optimize", response_model=OptimizeResponse)
def optimize(payload: OptimizeRequest):
    """
    Solves the timetable optimization problem via QUBO and simulated annealing.
    """
    if len(payload.classes) == 0:
        raise HTTPException(status_code=400, detail="Classes list cannot be empty.")
    if payload.slots <= 0:
        raise HTTPException(status_code=400, detail="Slots must be greater than zero.")

    raw_classes = [c.model_dump() for c in payload.classes]
    weights_dict = payload.weights.model_dump() if payload.weights else {"A": 10.0, "B": 15.0, "C": 1.0}

    try:
        result = optimize_timetable(
            classes=raw_classes,
            num_slots=payload.slots,
            weights=weights_dict,
            reads=payload.reads or 100,
            force_solver=payload.force_solver
        )
        return result
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Optimization solver failed: {str(e)}"
        )
