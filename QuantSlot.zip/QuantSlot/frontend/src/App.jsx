import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import LandingPage from './pages/LandingPage';
import DemoPage from './pages/DemoPage';
import HowItWorksPage from './pages/HowItWorksPage';
import AboutPage from './pages/AboutPage';
import { fetchHealth } from './services/api';

export default function App() {
  const [activePage, setActivePage] = useState('landing');
  const [isDark, setIsDark] = useState(() => {
    const saved = localStorage.getItem('quantslot_theme');
    if (saved) return saved === 'dark';
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  });
  const [backendStatus, setBackendStatus] = useState('checking');

  // Handle dark mode class on document
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('quantslot_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('quantslot_theme', 'light');
    }
  }, [isDark]);

  // Check backend health
  useEffect(() => {
    let isMounted = true;
    const check = async () => {
      try {
        const res = await fetchHealth();
        if (isMounted) {
          if (res.status === 'healthy') {
            setBackendStatus('healthy');
          } else {
            setBackendStatus('offline');
          }
        }
      } catch {
        if (isMounted) setBackendStatus('offline');
      }
    };
    check();
    const interval = setInterval(check, 10000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-navy-950 text-slate-900 dark:text-slate-100 transition-colors duration-200">
      {/* Navigation */}
      <Navbar
        activePage={activePage}
        setActivePage={setActivePage}
        isDark={isDark}
        setIsDark={setIsDark}
        backendStatus={backendStatus}
      />

      {/* Main Page View */}
      <main className="flex-1">
        {activePage === 'landing' && <LandingPage setActivePage={setActivePage} />}
        {activePage === 'demo' && <DemoPage setActivePage={setActivePage} />}
        {activePage === 'how-it-works' && <HowItWorksPage setActivePage={setActivePage} />}
        {activePage === 'about' && <AboutPage setActivePage={setActivePage} />}
      </main>

      {/* Footer */}
      <Footer setActivePage={setActivePage} />
    </div>
  );
}
