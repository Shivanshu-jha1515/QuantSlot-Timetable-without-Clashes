import React, { useState } from 'react';
import { Database, Binary, Cpu, CheckCircle2, ArrowRight, Zap, RefreshCw, Info } from 'lucide-react';

const STEPS = [
  {
    id: 1,
    title: '1. Ingest Data',
    subtitle: 'Extract Resources',
    icon: Database,
    color: 'from-blue-500 to-cyan-500',
    details: 'Parses courses, instructors, cohorts, and rooms. Pre-calculates pairwise resource intersection graphs.',
    formula: 'C = \\{c_1, c_2, \\dots, c_N\\}, \\quad S = \\{0, 1, \\dots, M-1\\}'
  },
  {
    id: 2,
    title: '2. Formulate QUBO',
    subtitle: 'Construct Q-Matrix',
    icon: Binary,
    color: 'from-cyan-500 to-teal-500',
    details: 'Maps scheduling into binary variables x(c, s) ∈ {0, 1}. Computes upper-triangular matrix Q incorporating H₁, H₂, and H₃ penalties.',
    formula: 'H(x) = x^T Q x + \\text{const} = W_A H_1 + W_B H_2 + W_C H_3'
  },
  {
    id: 3,
    title: '3. Anneal & Sample',
    subtitle: 'Explore Energy Well',
    icon: Cpu,
    color: 'from-teal-500 to-emerald-500',
    details: 'Simulated annealing cools a thermal/quantum distribution from high temperature T₀ down to 0, escaping local minima via Metropolis state flips.',
    formula: 'P(\\Delta E, T) = \\min\\left(1, e^{-\\Delta E / T}\\right)'
  },
  {
    id: 4,
    title: '4. Decode Bitstring',
    subtitle: 'State Space Extraction',
    icon: Zap,
    color: 'from-emerald-500 to-indigo-500',
    details: 'Extracts active binary spin states: x(c, s) = 1 assigns class c to period s. Resolves rare ties with greedy local refinement.',
    formula: '\\text{slot}(c) = \\arg\\max_s x_{c, s}'
  },
  {
    id: 5,
    title: '5. Validate & Output',
    subtitle: 'Zero-Clash Verification',
    icon: CheckCircle2,
    color: 'from-indigo-500 to-cyan-600',
    details: 'Calculates all resource pairs across slots. Confirms zero teacher, room, and group conflicts before publishing timetable.',
    formula: '\\text{Total Clashes} = \\sum_{s} \\sum_{c1 < c2} \\text{conflict}(c1, c2) = 0'
  },
];

export default function AlgorithmDiagram() {
  const [activeStep, setActiveStep] = useState(2);

  return (
    <div className="rounded-2xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 p-6 shadow-sm transition-colors">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800 gap-2">
        <div>
          <h3 className="font-bold text-lg text-slate-900 dark:text-white flex items-center space-x-2">
            <span>QuantSlot Algorithmic Pipeline</span>
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Click any step to inspect its transformation stage and mathematical formulation.
          </p>
        </div>
        <span className="text-[11px] font-mono px-2.5 py-1 rounded-full bg-cyan-100 dark:bg-cyan-950 text-cyan-700 dark:text-cyan-300 font-semibold self-start sm:self-auto">
          End-to-End Pipeline
        </span>
      </div>

      {/* Step Flow Ribbon */}
      <div className="grid grid-cols-1 sm:grid-cols-5 gap-2 my-6">
        {STEPS.map((step) => {
          const Icon = step.icon;
          const isSelected = activeStep === step.id;
          return (
            <button
              key={step.id}
              onClick={() => setActiveStep(step.id)}
              className={`p-3 rounded-xl border text-left transition-all relative ${
                isSelected
                  ? 'border-cyan-500 bg-cyan-50/70 dark:bg-cyan-950/40 shadow-sm'
                  : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-slate-50/40 dark:bg-navy-950/40'
              }`}
            >
              <div className="flex items-center space-x-2 mb-2">
                <div className={`w-7 h-7 rounded-lg bg-gradient-to-tr ${step.color} flex items-center justify-center text-white shadow-xs`}>
                  <Icon className="w-3.5 h-3.5" />
                </div>
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                  {step.title}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                {step.subtitle}
              </p>

              {isSelected && (
                <div className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-3 h-3 bg-cyan-500 rotate-45 hidden sm:block" />
              )}
            </button>
          );
        })}
      </div>

      {/* Active Step Deep Dive Card */}
      {(() => {
        const step = STEPS.find(s => s.id === activeStep) || STEPS[0];
        const Icon = step.icon;
        return (
          <div className="rounded-xl p-5 bg-gradient-to-r from-slate-50 to-cyan-50/30 dark:from-navy-950 dark:to-cyan-950/20 border border-cyan-200/60 dark:border-cyan-900/40 transition-all">
            <div className="flex items-start space-x-3">
              <div className={`w-9 h-9 rounded-xl bg-gradient-to-tr ${step.color} flex items-center justify-center text-white shadow-sm flex-shrink-0 mt-0.5`}>
                <Icon className="w-5 h-5" />
              </div>
              <div className="space-y-2 flex-1">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-slate-900 dark:text-white text-sm sm:text-base">
                    {step.title}: {step.subtitle}
                  </h4>
                  <span className="text-[11px] font-mono text-cyan-600 dark:text-cyan-400 font-semibold">
                    Step {step.id} of 5
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                  {step.details}
                </p>
                <div className="pt-2">
                  <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block mb-1">
                    Mathematical Formulation:
                  </span>
                  <code className="text-xs font-mono font-semibold px-3 py-1.5 rounded-lg bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 text-cyan-700 dark:text-cyan-300 block overflow-x-auto">
                    {step.formula}
                  </code>
                </div>
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
}
