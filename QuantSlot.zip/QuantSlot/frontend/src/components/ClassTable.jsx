import React, { useState, useMemo } from 'react';
import { Search, Plus, Trash2, Edit2, Check, X, BookOpen, User, MapPin, Users, RefreshCw } from 'lucide-react';

export default function ClassTable({ classes, setClasses, onResetSample }) {
  const [search, setSearch] = useState('');
  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState({});
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [newClass, setNewClass] = useState({
    id: '',
    name: '',
    teacher: '',
    group: '',
    room: ''
  });

  const filteredClasses = useMemo(() => {
    if (!search.trim()) return classes;
    const q = search.toLowerCase();
    return classes.filter(
      c =>
        c.id?.toLowerCase().includes(q) ||
        c.name?.toLowerCase().includes(q) ||
        c.teacher?.toLowerCase().includes(q) ||
        c.group?.toLowerCase().includes(q) ||
        c.room?.toLowerCase().includes(q)
    );
  }, [classes, search]);

  const startEdit = (cls) => {
    setEditingId(cls.id);
    setEditForm({ ...cls });
  };

  const saveEdit = () => {
    setClasses(classes.map(c => c.id === editingId ? { ...editForm } : c));
    setEditingId(null);
  };

  const cancelEdit = () => {
    setEditingId(null);
  };

  const deleteClass = (id) => {
    setClasses(classes.filter(c => c.id !== id));
  };

  const handleAddNew = (e) => {
    e.preventDefault();
    if (!newClass.name) return;
    const cid = newClass.id.trim() || `CLS_${classes.length + 1}`;
    setClasses([...classes, { ...newClass, id: cid }]);
    setNewClass({ id: '', name: '', teacher: '', group: '', room: '' });
    setIsAddingNew(false);
  };

  return (
    <div className="rounded-2xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden transition-colors">
      {/* Header */}
      <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <h3 className="font-bold text-slate-900 dark:text-white text-base sm:text-lg flex items-center space-x-2">
            <span>Class Schedule Input</span>
          </h3>
          <span className="px-2 py-0.5 rounded-full text-xs font-mono font-semibold bg-slate-100 dark:bg-navy-800 text-slate-700 dark:text-slate-300">
            {classes.length} classes
          </span>
        </div>

        <div className="flex items-center space-x-2">
          {/* Search box */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search classes, rooms, teachers..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-8 pr-3 py-1.5 text-xs rounded-xl bg-slate-50 dark:bg-navy-950 border border-slate-200 dark:border-slate-800 focus:outline-none focus:border-cyan-500 text-slate-800 dark:text-slate-200 w-44 sm:w-60"
            />
          </div>

          {/* Add class button */}
          <button
            onClick={() => setIsAddingNew(!isAddingNew)}
            className="flex items-center space-x-1 px-3 py-1.5 text-xs font-semibold rounded-xl bg-teal-600 hover:bg-teal-500 text-white shadow-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Class</span>
          </button>
        </div>
      </div>

      {/* Add New Class Form Accordion */}
      {isAddingNew && (
        <form onSubmit={handleAddNew} className="p-4 bg-teal-50/50 dark:bg-cyan-950/20 border-b border-teal-100 dark:border-cyan-900/40 grid grid-cols-1 sm:grid-cols-6 gap-2 text-xs">
          <input
            type="text"
            placeholder="Class ID (e.g. CS106)"
            value={newClass.id}
            onChange={(e) => setNewClass({ ...newClass, id: e.target.value })}
            className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-navy-900 text-slate-800 dark:text-slate-200"
          />
          <input
            type="text"
            placeholder="Course Name *"
            required
            value={newClass.name}
            onChange={(e) => setNewClass({ ...newClass, name: e.target.value })}
            className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-navy-900 text-slate-800 dark:text-slate-200 sm:col-span-2"
          />
          <input
            type="text"
            placeholder="Teacher"
            value={newClass.teacher}
            onChange={(e) => setNewClass({ ...newClass, teacher: e.target.value })}
            className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-navy-900 text-slate-800 dark:text-slate-200"
          />
          <input
            type="text"
            placeholder="Cohort / Group"
            value={newClass.group}
            onChange={(e) => setNewClass({ ...newClass, group: e.target.value })}
            className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-navy-900 text-slate-800 dark:text-slate-200"
          />
          <div className="flex items-center space-x-1 sm:col-span-1">
            <input
              type="text"
              placeholder="Room"
              value={newClass.room}
              onChange={(e) => setNewClass({ ...newClass, room: e.target.value })}
              className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-navy-900 text-slate-800 dark:text-slate-200 w-full"
            />
            <button
              type="submit"
              className="p-1.5 bg-teal-600 text-white rounded-lg hover:bg-teal-500"
            >
              <Check className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setIsAddingNew(false)}
              className="p-1.5 bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-lg hover:bg-slate-300"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </form>
      )}

      {/* Table */}
      <div className="max-h-[380px] overflow-y-auto">
        <table className="w-full text-left text-xs text-slate-600 dark:text-slate-300">
          <thead className="sticky top-0 bg-slate-100/90 dark:bg-navy-950/90 backdrop-blur-xs text-[11px] uppercase tracking-wider text-slate-500 dark:text-slate-400 font-mono border-b border-slate-200 dark:border-slate-800">
            <tr>
              <th className="py-2.5 px-3">ID</th>
              <th className="py-2.5 px-3">Course Title</th>
              <th className="py-2.5 px-3">Teacher</th>
              <th className="py-2.5 px-3">Cohort</th>
              <th className="py-2.5 px-3">Room</th>
              <th className="py-2.5 px-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-sans">
            {filteredClasses.length === 0 ? (
              <tr>
                <td colSpan="6" className="py-8 text-center text-slate-400 italic">
                  No classes matching "{search}"
                </td>
              </tr>
            ) : (
              filteredClasses.map((cls) => {
                const isEditing = editingId === cls.id;
                return (
                  <tr key={cls.id} className="hover:bg-slate-50/70 dark:hover:bg-navy-800/40 transition-colors">
                    {isEditing ? (
                      <>
                        <td className="p-2 font-mono text-cyan-600 dark:text-cyan-400 font-bold">{cls.id}</td>
                        <td className="p-2">
                          <input
                            type="text"
                            value={editForm.name}
                            onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                            className="w-full px-2 py-1 text-xs rounded border border-cyan-400 bg-white dark:bg-navy-950"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="text"
                            value={editForm.teacher}
                            onChange={(e) => setEditForm({ ...editForm, teacher: e.target.value })}
                            className="w-full px-2 py-1 text-xs rounded border border-cyan-400 bg-white dark:bg-navy-950"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="text"
                            value={editForm.group}
                            onChange={(e) => setEditForm({ ...editForm, group: e.target.value })}
                            className="w-full px-2 py-1 text-xs rounded border border-cyan-400 bg-white dark:bg-navy-950"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="text"
                            value={editForm.room}
                            onChange={(e) => setEditForm({ ...editForm, room: e.target.value })}
                            className="w-full px-2 py-1 text-xs rounded border border-cyan-400 bg-white dark:bg-navy-950"
                          />
                        </td>
                        <td className="p-2 text-right space-x-1">
                          <button onClick={saveEdit} className="p-1 text-emerald-600 hover:bg-emerald-50 rounded">
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button onClick={cancelEdit} className="p-1 text-slate-400 hover:bg-slate-100 rounded">
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </>
                    ) : (
                      <>
                        <td className="py-2 px-3 font-mono font-semibold text-slate-900 dark:text-slate-100">
                          {cls.id}
                        </td>
                        <td className="py-2 px-3 font-medium text-slate-900 dark:text-slate-200">
                          {cls.name}
                        </td>
                        <td className="py-2 px-3 text-slate-600 dark:text-slate-400 flex items-center space-x-1.5 mt-1">
                          <User className="w-3 h-3 text-slate-400 flex-shrink-0" />
                          <span>{cls.teacher}</span>
                        </td>
                        <td className="py-2 px-3">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 dark:bg-navy-950 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800">
                            {cls.group}
                          </span>
                        </td>
                        <td className="py-2 px-3">
                          <span className="font-mono text-slate-600 dark:text-slate-400 flex items-center space-x-1">
                            <MapPin className="w-3 h-3 text-slate-400 flex-shrink-0" />
                            <span>{cls.room}</span>
                          </span>
                        </td>
                        <td className="py-2 px-3 text-right space-x-1">
                          <button
                            onClick={() => startEdit(cls)}
                            className="p-1 text-slate-400 hover:text-cyan-600 dark:hover:text-cyan-400 transition-colors"
                            title="Edit class"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => deleteClass(cls.id)}
                            className="p-1 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 transition-colors"
                            title="Delete class"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </>
                    )}
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
