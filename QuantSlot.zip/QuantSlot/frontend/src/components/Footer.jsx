import React from 'react';
import { Atom, Cpu, ExternalLink } from 'lucide-react';

export default function Footer({ setActivePage }) {
  return (
    <footer className="border-t border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-navy-950/50 backdrop-blur-sm transition-colors mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand col */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center space-x-2">
              <div className="w-7 h-7 rounded-lg bg-cyan-600 flex items-center justify-center text-white">
                <Atom className="w-4 h-4" />
              </div>
              <span className="font-bold text-lg text-slate-900 dark:text-white">QuantSlot</span>
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-400 max-w-sm">
              "From 18 clashes to zero, in seconds." Quantum-inspired combinatorial optimization solving school and university timetabling using QUBO and simulated annealing.
            </p>
            <div className="flex items-center space-x-2 text-xs text-slate-500 dark:text-slate-500 font-mono">
              <Cpu className="w-3.5 h-3.5 text-cyan-500" />
              <span>D-Wave Neal + Pure Python Fallback Engine</span>
            </div>
          </div>

          {/* Quick links */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-900 dark:text-slate-200 mb-3">
              Navigation
            </h4>
            <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-400">
              <li>
                <button onClick={() => setActivePage('landing')} className="hover:text-cyan-600 dark:hover:text-cyan-400 transition-colors">
                  Overview
                </button>
              </li>
              <li>
                <button onClick={() => setActivePage('demo')} className="hover:text-cyan-600 dark:hover:text-cyan-400 transition-colors">
                  Live Timetable Demo
                </button>
              </li>
              <li>
                <button onClick={() => setActivePage('how-it-works')} className="hover:text-cyan-600 dark:hover:text-cyan-400 transition-colors">
                  QUBO Mathematical Model
                </button>
              </li>
              <li>
                <button onClick={() => setActivePage('about')} className="hover:text-cyan-600 dark:hover:text-cyan-400 transition-colors">
                  Architecture & Roadmap
                </button>
              </li>
            </ul>
          </div>

          {/* Constraints Handled */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-900 dark:text-slate-200 mb-3">
              Hamiltonian Terms
            </h4>
            <ul className="space-y-1.5 text-xs text-slate-600 dark:text-slate-400 font-mono">
              <li className="flex items-center space-x-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-500" />
                <span>H₁: Exactly 1 slot per class</span>
              </li>
              <li className="flex items-center space-x-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-teal-500" />
                <span>H₂: Zero teacher conflicts</span>
              </li>
              <li className="flex items-center space-x-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                <span>H₂: Zero room double-bookings</span>
              </li>
              <li className="flex items-center space-x-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                <span>H₂: Zero student cohort clashes</span>
              </li>
              <li className="flex items-center space-x-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                <span>H₃: Soft time slot balancing</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 dark:text-slate-400">
          <p>© {new Date().getFullYear()} QuantSlot. Designed & Developed solely by <span className="font-semibold text-slate-800 dark:text-slate-200">Shivanshu Jha</span>.</p>
          <div className="flex items-center space-x-4 mt-4 sm:mt-0">
            <span className="flex items-center space-x-1">
              <span>Engineered with FastAPI + React + D-Wave Neal</span>
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
