import React from 'react';
import { Atom, Moon, Sun, Sparkles, CheckCircle2, AlertCircle } from 'lucide-react';

export default function Navbar({ activePage, setActivePage, isDark, setIsDark, backendStatus }) {
  const navItems = [
    { id: 'landing', label: 'Overview' },
    { id: 'demo', label: 'Live Optimizer' },
    { id: 'how-it-works', label: 'How It Works' },
    { id: 'about', label: 'About & Tech' },
  ];

  return (
    <header className="sticky top-0 z-50 backdrop-blur-md bg-white/80 dark:bg-navy-950/80 border-b border-slate-200 dark:border-slate-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand */}
        <div 
          onClick={() => setActivePage('landing')} 
          className="flex items-center space-x-3 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 via-teal-500 to-blue-600 p-0.5 shadow-md shadow-cyan-500/20 group-hover:scale-105 transition-transform">
            <div className="w-full h-full bg-white dark:bg-navy-900 rounded-[10px] flex items-center justify-center">
              <Atom className="w-5 h-5 text-cyan-600 dark:text-cyan-400 group-hover:rotate-180 transition-transform duration-700" />
            </div>
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-extrabold text-lg tracking-tight bg-gradient-to-r from-slate-900 via-cyan-900 to-slate-700 dark:from-white dark:via-cyan-200 dark:to-teal-400 bg-clip-text text-transparent">
                QuantSlot
              </span>
              <span className="text-[10px] uppercase font-mono font-semibold px-2 py-0.5 rounded-full bg-cyan-100 dark:bg-cyan-950/80 text-cyan-700 dark:text-cyan-300 border border-cyan-200 dark:border-cyan-800">
                QUBO v1.0
              </span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 hidden sm:block">
              Quantum-Inspired Timetable Optimizer
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="hidden md:flex items-center space-x-1 bg-slate-100/70 dark:bg-navy-900/60 p-1 rounded-xl border border-slate-200/60 dark:border-slate-800">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActivePage(item.id)}
              className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
                activePage === item.id
                  ? 'bg-white dark:bg-cyan-950 text-cyan-600 dark:text-cyan-300 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* Right Action: Backend Status & Dark Mode Toggle */}
        <div className="flex items-center space-x-3">
          {/* Backend Status indicator */}
          <div 
            title={backendStatus === 'healthy' ? 'FastAPI Backend Connected' : 'Checking Backend'}
            className="flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-xs font-mono border bg-slate-50 dark:bg-navy-900 border-slate-200 dark:border-slate-800"
          >
            <span className={`w-2 h-2 rounded-full ${
              backendStatus === 'healthy' ? 'bg-emerald-500 animate-pulse' : 'bg-amber-400'
            }`} />
            <span className="text-slate-600 dark:text-slate-400 text-[11px] hidden sm:inline">
              {backendStatus === 'healthy' ? 'Backend Live' : 'Connecting...'}
            </span>
          </div>

          {/* Theme Toggle */}
          <button
            onClick={() => setIsDark(!isDark)}
            className="p-2 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-navy-900 border border-transparent hover:border-slate-200 dark:hover:border-slate-800 transition-colors"
            aria-label="Toggle theme"
          >
            {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-700" />}
          </button>

          {/* CTA Button */}
          <button
            onClick={() => setActivePage('demo')}
            className="hidden sm:inline-flex items-center space-x-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white shadow-sm shadow-cyan-600/30 transition-all hover:shadow-cyan-600/50"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Launch Demo</span>
          </button>
        </div>
      </div>

      {/* Mobile nav bar */}
      <div className="md:hidden flex items-center justify-around py-2 border-t border-slate-200 dark:border-slate-800 bg-slate-50/90 dark:bg-navy-900/90 px-2">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActivePage(item.id)}
            className={`px-2.5 py-1 text-xs font-medium rounded-lg ${
              activePage === item.id
                ? 'bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 font-semibold'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>
    </header>
  );
}
