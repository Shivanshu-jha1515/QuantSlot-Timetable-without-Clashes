import React, { useEffect, useState } from 'react';
import { Zap, Clock, ShieldAlert, Sparkles, CheckCircle2, TrendingDown, Layers } from 'lucide-react';
import confetti from 'canvas-confetti';

export default function ResultsCounter({
  before = 18,
  after = 0,
  solveTime = 818.89,
  solver = 'dwave-neal',
  quboVars = 360,
  triggerAnimation = true,
  isLanding = false
}) {
  const [displayClashes, setDisplayClashes] = useState(before);
  const [hasAnimated, setHasAnimated] = useState(false);

  useEffect(() => {
    if (!triggerAnimation) {
      setDisplayClashes(after);
      return;
    }

    let start = before;
    const end = after;
    const duration = 1200; // ms
    const startTime = performance.now();

    const animate = (currentTime) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      // Easing out cubic
      const ease = 1 - Math.pow(1 - progress, 3);
      const currentVal = Math.round(start - (start - end) * ease);
      setDisplayClashes(currentVal);

      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        setDisplayClashes(end);
        if (end === 0 && !hasAnimated) {
          setHasAnimated(true);
          // Trigger confetti burst on zero clashes!
          try {
            confetti({
              particleCount: 50,
              spread: 60,
              origin: { y: 0.65 },
              colors: ['#06b6d4', '#14b8a6', '#3b82f6', '#10b981']
            });
          } catch (e) {
            // Non-critical if canvas fails
          }
        }
      }
    };

    const animId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animId);
  }, [before, after, triggerAnimation]);

  const reduction = before > 0 ? Math.round(((before - after) / before) * 100) : 100;

  if (isLanding) {
    return (
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-900 via-navy-900 to-cyan-950 p-6 sm:p-8 border border-cyan-500/20 shadow-2xl shadow-cyan-950/50 text-white">
        <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center md:text-left">
            <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-mono font-medium">
              <Zap className="w-3.5 h-3.5 text-cyan-400" />
              <span>Verified Annealing Benchmark</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-bold tracking-tight">
              Real-Time Clash Eradication
            </h3>
            <p className="text-sm text-slate-300 max-w-md">
              Watch simultaneous resource clashes (teachers, rooms, groups) resolve into a conflict-free timetable.
            </p>
          </div>

          <div className="flex items-center space-x-4 sm:space-x-8">
            {/* Clashes count badge */}
            <div className="flex flex-col items-center bg-white/5 border border-white/10 rounded-2xl px-6 py-4 backdrop-blur-md">
              <span className="text-xs uppercase font-mono tracking-wider text-slate-400">
                Active Clashes
              </span>
              <div className="flex items-baseline space-x-2 my-1">
                <span className={`text-4xl sm:text-5xl font-black font-mono transition-colors duration-300 ${
                  displayClashes === 0 ? 'text-teal-400' : 'text-rose-400'
                }`}>
                  {displayClashes}
                </span>
                <span className="text-xs text-slate-400 line-through">
                  from {before}
                </span>
              </div>
              <span className={`text-[11px] font-semibold flex items-center space-x-1 ${
                displayClashes === 0 ? 'text-teal-300' : 'text-amber-300'
              }`}>
                {displayClashes === 0 ? (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>0 Clashes Guaranteed</span>
                  </>
                ) : (
                  <>
                    <ShieldAlert className="w-3.5 h-3.5" />
                    <span>Optimizing Hamiltonian...</span>
                  </>
                )}
              </span>
            </div>

            {/* Time metric */}
            <div className="flex flex-col items-center bg-white/5 border border-white/10 rounded-2xl px-6 py-4 backdrop-blur-md">
              <span className="text-xs uppercase font-mono tracking-wider text-slate-400">
                Anneal Time
              </span>
              <div className="flex items-baseline space-x-1 my-1">
                <span className="text-3xl sm:text-4xl font-black font-mono text-cyan-300">
                  {solveTime < 1000 ? Math.round(solveTime) : (solveTime / 1000).toFixed(2)}
                </span>
                <span className="text-xs font-mono text-slate-400">
                  {solveTime < 1000 ? 'ms' : 's'}
                </span>
              </div>
              <span className="text-[11px] font-mono text-cyan-400/80 flex items-center space-x-1">
                <Clock className="w-3 h-3" />
                <span>Sub-second solve</span>
              </span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Demo Page Metric Banner
  return (
    <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4 my-6">
      {/* Metric 1: Clashes Before */}
      <div className="p-4 rounded-xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-medium">
          <span>Initial Clashes</span>
          <ShieldAlert className="w-4 h-4 text-rose-500" />
        </div>
        <div className="mt-2 flex items-baseline space-x-1">
          <span className="text-2xl sm:text-3xl font-bold font-mono text-slate-800 dark:text-slate-100">
            {before}
          </span>
          <span className="text-xs text-rose-500 font-medium">conflicts</span>
        </div>
        <span className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">Unoptimized baseline</span>
      </div>

      {/* Metric 2: Clashes After (Hero stat) */}
      <div className="p-4 rounded-xl bg-gradient-to-br from-teal-50 to-cyan-50 dark:from-cyan-950/40 dark:to-teal-950/40 border border-teal-200 dark:border-teal-800/60 shadow-sm flex flex-col justify-between">
        <div className="flex items-center justify-between text-teal-700 dark:text-teal-300 text-xs font-semibold">
          <span>Optimized Clashes</span>
          <CheckCircle2 className="w-4 h-4 text-teal-500" />
        </div>
        <div className="mt-2 flex items-baseline space-x-2">
          <span className="text-3xl sm:text-4xl font-extrabold font-mono text-teal-600 dark:text-teal-400">
            {displayClashes}
          </span>
          {after === 0 && (
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-teal-500 text-white">
              Zero Clashes
            </span>
          )}
        </div>
        <div className="flex items-center space-x-1 text-[11px] text-teal-700 dark:text-teal-300 mt-1">
          <TrendingDown className="w-3 h-3" />
          <span>{reduction}% clash reduction</span>
        </div>
      </div>

      {/* Metric 3: Solve Time */}
      <div className="p-4 rounded-xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-medium">
          <span>Solve Time</span>
          <Clock className="w-4 h-4 text-cyan-500" />
        </div>
        <div className="mt-2 flex items-baseline space-x-1">
          <span className="text-2xl sm:text-3xl font-bold font-mono text-cyan-600 dark:text-cyan-400">
            {solveTime}
          </span>
          <span className="text-xs text-slate-500 font-mono">ms</span>
        </div>
        <span className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">FastAPI + Annealer</span>
      </div>

      {/* Metric 4: QUBO Variables */}
      <div className="p-4 rounded-xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-medium">
          <span>QUBO Variables</span>
          <Layers className="w-4 h-4 text-indigo-500" />
        </div>
        <div className="mt-2 flex items-baseline space-x-1">
          <span className="text-2xl sm:text-3xl font-bold font-mono text-indigo-600 dark:text-indigo-400">
            {quboVars}
          </span>
          <span className="text-xs text-slate-500 font-mono">x(c,s)</span>
        </div>
        <span className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">Binary state space</span>
      </div>

      {/* Metric 5: Solver Engine */}
      <div className="col-span-2 lg:col-span-1 p-4 rounded-xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-medium">
          <span>Active Solver</span>
          <Zap className="w-4 h-4 text-amber-500" />
        </div>
        <div className="mt-2">
          <span className="text-xs sm:text-sm font-bold font-mono text-slate-800 dark:text-slate-200 truncate block" title={solver}>
            {solver.includes('dwave') ? 'dwave-neal' : 'pure-python'}
          </span>
        </div>
        <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium mt-1 flex items-center space-x-1">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
          <span>Simulated Annealing</span>
        </span>
      </div>
    </div>
  );
}
