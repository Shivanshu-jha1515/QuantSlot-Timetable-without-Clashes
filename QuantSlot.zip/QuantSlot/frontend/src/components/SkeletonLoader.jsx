import React from 'react';

export function TimetableSkeleton({ slots = 12 }) {
  const periods = slots <= 12 ? 4 : 5;
  const days = Math.ceil(slots / periods);

  return (
    <div className="rounded-2xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 p-6 shadow-sm animate-pulse space-y-6">
      <div className="flex justify-between items-center pb-4 border-b border-slate-100 dark:border-slate-800">
        <div className="space-y-2">
          <div className="h-6 w-48 bg-slate-200 dark:bg-navy-800 rounded-md" />
          <div className="h-3 w-64 bg-slate-100 dark:bg-navy-800/60 rounded" />
        </div>
        <div className="flex space-x-2">
          <div className="h-8 w-24 bg-slate-200 dark:bg-navy-800 rounded-xl" />
          <div className="h-8 w-28 bg-slate-200 dark:bg-navy-800 rounded-xl" />
        </div>
      </div>

      <div className="space-y-4">
        {Array.from({ length: Math.min(days, 3) }).map((_, d) => (
          <div key={d} className="rounded-xl border border-slate-200 dark:border-slate-800 p-4 space-y-3">
            <div className="h-4 w-28 bg-slate-200 dark:bg-navy-800 rounded" />
            <div className="grid grid-cols-4 gap-3">
              {Array.from({ length: 4 }).map((_, p) => (
                <div key={p} className="h-32 bg-slate-100 dark:bg-navy-800/50 rounded-xl border border-slate-200/50 dark:border-slate-800/40 p-3 space-y-2">
                  <div className="h-3 w-12 bg-slate-200 dark:bg-navy-800 rounded" />
                  <div className="h-10 bg-slate-200 dark:bg-navy-800 rounded-lg" />
                  <div className="h-6 bg-slate-200 dark:bg-navy-800 rounded-md" />
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function MetricSkeleton() {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 my-6 animate-pulse">
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} className="p-4 rounded-xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 space-y-2">
          <div className="h-3 w-20 bg-slate-200 dark:bg-navy-800 rounded" />
          <div className="h-8 w-16 bg-slate-200 dark:bg-navy-800 rounded-md" />
          <div className="h-2 w-24 bg-slate-100 dark:bg-navy-800/60 rounded" />
        </div>
      ))}
    </div>
  );
}
