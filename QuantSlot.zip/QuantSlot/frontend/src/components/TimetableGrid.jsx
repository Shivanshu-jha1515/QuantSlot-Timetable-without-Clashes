import React, { useState, useMemo } from 'react';
import { Download, AlertTriangle, CheckCircle, Filter, Eye, RefreshCw, Layers, User, MapPin, Users } from 'lucide-react';
import { downloadCSV } from '../services/api';

// Distinct color generator based on group string
const GROUP_COLORS = {
  'CS-Year1': 'bg-sky-100 text-sky-800 border-sky-300 dark:bg-sky-950/70 dark:text-sky-300 dark:border-sky-800',
  'CS-Year2': 'bg-indigo-100 text-indigo-800 border-indigo-300 dark:bg-indigo-950/70 dark:text-indigo-300 dark:border-indigo-800',
  'Physics-Year1': 'bg-purple-100 text-purple-800 border-purple-300 dark:bg-purple-950/70 dark:text-purple-300 dark:border-purple-800',
  'Math-Year1': 'bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-950/70 dark:text-emerald-300 dark:border-emerald-800',
  'DataScience-Year2': 'bg-amber-100 text-amber-800 border-amber-300 dark:bg-amber-950/70 dark:text-amber-300 dark:border-amber-800',
  'Bio-Year1': 'bg-rose-100 text-rose-800 border-rose-300 dark:bg-rose-950/70 dark:text-rose-300 dark:border-rose-800',
};

const DEFAULT_GROUP_COLOR = 'bg-teal-100 text-teal-800 border-teal-300 dark:bg-teal-950/70 dark:text-teal-300 dark:border-teal-800';

export default function TimetableGrid({
  assignment = [],
  baselineAssignment = [],
  slots = 12,
  clashesBefore = 18,
  clashesAfter = 0,
  solveTime = 800,
  clashDetailsAfter = [],
  clashDetailsBefore = []
}) {
  const [highlightConflicts, setHighlightConflicts] = useState(true);
  const [selectedGroup, setSelectedGroup] = useState('ALL');
  const [viewMode, setViewMode] = useState('optimized'); // 'optimized' or 'baseline'
  const [activeModalClash, setActiveModalClash] = useState(null);

  // Active data based on view mode
  const activeAssignment = viewMode === 'optimized' ? assignment : baselineAssignment;
  const activeClashes = viewMode === 'optimized' ? clashesAfter : clashesBefore;
  const activeDetails = viewMode === 'optimized' ? clashDetailsAfter : clashDetailsBefore;

  // Grid dimensions
  const periodsPerDay = slots <= 12 ? 4 : (slots <= 20 ? 4 : 5);
  const totalDays = Math.ceil(slots / periodsPerDay);
  const dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].slice(0, Math.max(totalDays, 3));

  // Extract unique groups for filtering
  const uniqueGroups = useMemo(() => {
    const s = new Set();
    assignment.forEach(c => { if (c.group) s.add(c.group); });
    return Array.from(s).sort();
  }, [assignment]);

  // Build slot map: slotIndex -> array of classes
  const slotMap = useMemo(() => {
    const map = {};
    for (let s = 0; s < slots; s++) map[s] = [];

    activeAssignment.forEach(cls => {
      const s = cls.slot;
      if (s != null && s >= 0 && s < slots) {
        if (selectedGroup === 'ALL' || cls.group === selectedGroup) {
          map[s].push(cls);
        }
      }
    });
    return map;
  }, [activeAssignment, slots, selectedGroup]);

  // Detect clashes in each slot
  const slotClashes = useMemo(() => {
    const clashesBySlot = {};
    for (let s = 0; s < slots; s++) {
      const items = slotMap[s] || [];
      const conflicts = [];
      const n = items.length;
      for (let i = 0; i < n; i++) {
        for (let j = i + 1; j < n; j++) {
          const reasons = [];
          if (items[i].teacher && items[i].teacher === items[j].teacher) reasons.push(`Teacher (${items[i].teacher})`);
          if (items[i].room && items[i].room === items[j].room) reasons.push(`Room (${items[i].room})`);
          if (items[i].group && items[i].group === items[j].group) reasons.push(`Student Group (${items[i].group})`);
          if (reasons.length > 0) {
            conflicts.push({
              class1: items[i],
              class2: items[j],
              reasons
            });
          }
        }
      }
      clashesBySlot[s] = conflicts;
    }
    return clashesBySlot;
  }, [slotMap, slots]);

  const handleDownload = () => {
    downloadCSV(activeAssignment, slots, `quant_slot_${viewMode}_timetable.csv`);
  };

  return (
    <div className="rounded-2xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden transition-colors">
      {/* Top Header & Toolbar */}
      <div className="p-4 sm:p-6 border-b border-slate-200 dark:border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-3">
            <h3 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white flex items-center space-x-2">
              <span>Timetable Master Schedule</span>
            </h3>
            <span className={`px-2.5 py-0.5 rounded-full text-xs font-mono font-bold flex items-center space-x-1 ${
              activeClashes === 0 
                ? 'bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300' 
                : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
            }`}>
              {activeClashes === 0 ? <CheckCircle className="w-3.5 h-3.5" /> : <AlertTriangle className="w-3.5 h-3.5" />}
              <span>{activeClashes} clashes in current view</span>
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Displaying {slots} time slots organized into {totalDays} days × {periodsPerDay} periods.
          </p>
        </div>

        {/* Toolbar Controls */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* View Mode Toggle (Optimized vs Baseline) */}
          <div className="flex items-center p-1 bg-slate-100 dark:bg-navy-950 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-medium">
            <button
              onClick={() => setViewMode('optimized')}
              className={`px-3 py-1 rounded-lg transition-all ${
                viewMode === 'optimized'
                  ? 'bg-teal-500 text-white shadow-sm font-semibold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              Optimized (0 Clashes)
            </button>
            <button
              onClick={() => setViewMode('baseline')}
              className={`px-3 py-1 rounded-lg transition-all ${
                viewMode === 'baseline'
                  ? 'bg-rose-500 text-white shadow-sm font-semibold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              Before ({clashesBefore} Clashes)
            </button>
          </div>

          {/* Group Filter */}
          <div className="flex items-center space-x-1.5 bg-slate-100 dark:bg-navy-950 px-2.5 py-1 rounded-xl border border-slate-200 dark:border-slate-800 text-xs">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={selectedGroup}
              onChange={(e) => setSelectedGroup(e.target.value)}
              className="bg-transparent text-slate-700 dark:text-slate-200 font-medium focus:outline-none cursor-pointer"
            >
              <option value="ALL">All Cohorts ({uniqueGroups.length})</option>
              {uniqueGroups.map(g => (
                <option key={g} value={g} className="dark:bg-navy-900">{g}</option>
              ))}
            </select>
          </div>

          {/* Conflict Highlight Toggle */}
          <button
            onClick={() => setHighlightConflicts(!highlightConflicts)}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-medium border transition-colors ${
              highlightConflicts
                ? 'bg-rose-50 border-rose-200 text-rose-700 dark:bg-rose-950/40 dark:border-rose-900 dark:text-rose-300'
                : 'bg-slate-100 border-slate-200 text-slate-600 dark:bg-navy-950 dark:border-slate-800 dark:text-slate-400'
            }`}
          >
            <AlertTriangle className={`w-3.5 h-3.5 ${highlightConflicts ? 'text-rose-500' : 'text-slate-400'}`} />
            <span>Conflict Highlight</span>
          </button>

          {/* Download CSV */}
          <button
            onClick={handleDownload}
            className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-cyan-600 hover:bg-cyan-500 text-white shadow-sm transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download CSV</span>
          </button>
        </div>
      </div>

      {/* Grid Content */}
      <div className="overflow-x-auto p-4 sm:p-6">
        <div className="min-w-[760px] grid gap-4">
          {dayNames.map((dayName, dayIndex) => {
            const daySlotStart = dayIndex * periodsPerDay;
            // Check if day has any slots inside total slots
            if (daySlotStart >= slots) return null;

            return (
              <div key={dayName} className="rounded-xl border border-slate-200 dark:border-slate-800/80 bg-slate-50/50 dark:bg-navy-950/50 p-3 sm:p-4">
                <div className="flex items-center justify-between mb-3">
                  <span className="font-bold text-sm text-slate-800 dark:text-slate-200 tracking-wide uppercase">
                    {dayName}
                  </span>
                  <span className="text-[11px] font-mono text-slate-400">
                    Slots {daySlotStart} – {Math.min(daySlotStart + periodsPerDay - 1, slots - 1)}
                  </span>
                </div>

                <div className={`grid grid-cols-${periodsPerDay} gap-3`} style={{ gridTemplateColumns: `repeat(${periodsPerDay}, minmax(0, 1fr))` }}>
                  {Array.from({ length: periodsPerDay }).map((_, periodIndex) => {
                    const slotIndex = daySlotStart + periodIndex;
                    if (slotIndex >= slots) {
                      return (
                        <div key={periodIndex} className="p-3 rounded-lg border border-dashed border-slate-200 dark:border-slate-800/50 bg-transparent flex items-center justify-center text-xs text-slate-400">
                          Inactive Slot
                        </div>
                      );
                    }

                    const classesInSlot = slotMap[slotIndex] || [];
                    const conflicts = slotClashes[slotIndex] || [];
                    const hasConflict = conflicts.length > 0 && highlightConflicts;

                    return (
                      <div
                        key={periodIndex}
                        className={`rounded-xl border p-2.5 flex flex-col justify-between min-h-[140px] transition-all ${
                          hasConflict
                            ? 'bg-rose-50/80 dark:bg-rose-950/30 border-rose-300 dark:border-rose-800 shadow-sm shadow-rose-500/10'
                            : 'bg-white dark:bg-navy-900 border-slate-200 dark:border-slate-800/80 hover:border-cyan-400 dark:hover:border-cyan-600'
                        }`}
                      >
                        {/* Slot Header */}
                        <div className="flex items-center justify-between pb-1.5 border-b border-slate-100 dark:border-slate-800/60 text-[11px] font-mono text-slate-400">
                          <span className="font-semibold text-slate-600 dark:text-slate-300">
                            P{periodIndex + 1}
                          </span>
                          <span className="text-[10px]">
                            Slot #{slotIndex}
                          </span>
                        </div>

                        {/* Clashes Alert Banner if any */}
                        {hasConflict && (
                          <button
                            onClick={() => setActiveModalClash({ slot: slotIndex, conflicts })}
                            className="mt-1.5 mb-1 py-1 px-2 rounded-lg bg-rose-100 dark:bg-rose-900/60 border border-rose-300 dark:border-rose-700 text-rose-800 dark:text-rose-200 text-[10px] font-semibold flex items-center justify-between w-full hover:bg-rose-200 transition-colors"
                          >
                            <span className="flex items-center space-x-1">
                              <AlertTriangle className="w-3 h-3 text-rose-600 dark:text-rose-400 flex-shrink-0" />
                              <span>{conflicts.length} Clash{conflicts.length > 1 ? 'es' : ''} Detected!</span>
                            </span>
                            <Eye className="w-3 h-3" />
                          </button>
                        )}

                        {/* Class Cards */}
                        <div className="space-y-1.5 mt-1.5 flex-1">
                          {classesInSlot.length === 0 ? (
                            <div className="h-full flex items-center justify-center text-[11px] text-slate-400 italic">
                              Free period
                            </div>
                          ) : (
                            classesInSlot.map((cls) => {
                              const colorClass = GROUP_COLORS[cls.group] || DEFAULT_GROUP_COLOR;
                              return (
                                <div
                                  key={cls.id}
                                  className={`p-2 rounded-lg border text-xs shadow-xs transition-transform hover:scale-[1.01] ${colorClass}`}
                                >
                                  <div className="flex items-center justify-between font-bold">
                                    <span className="truncate">{cls.name}</span>
                                    <span className="text-[10px] opacity-75 font-mono ml-1">{cls.id}</span>
                                  </div>

                                  <div className="mt-1 flex flex-col space-y-0.5 text-[10px] opacity-90">
                                    <div className="flex items-center space-x-1 truncate">
                                      <User className="w-2.5 h-2.5 flex-shrink-0" />
                                      <span className="truncate">{cls.teacher}</span>
                                    </div>
                                    <div className="flex items-center justify-between">
                                      <span className="flex items-center space-x-1 truncate">
                                        <MapPin className="w-2.5 h-2.5 flex-shrink-0" />
                                        <span>{cls.room}</span>
                                      </span>
                                      <span className="font-semibold text-[9px] px-1 py-0.2 rounded bg-black/5 dark:bg-white/10">
                                        {cls.group}
                                      </span>
                                    </div>
                                  </div>
                                </div>
                              );
                            })
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Clash Inspection Modal */}
      {activeModalClash && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center space-x-2 text-rose-600 dark:text-rose-400">
                <AlertTriangle className="w-5 h-5" />
                <h4 className="font-bold text-base">
                  Slot #{activeModalClash.slot} Conflict Breakdown
                </h4>
              </div>
              <button
                onClick={() => setActiveModalClash(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-sm font-semibold"
              >
                ✕ Close
              </button>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-400 my-3">
              The following class pairs were assigned concurrently in Slot #{activeModalClash.slot}, violating the H₂ no-clash QUBO objective term:
            </p>

            <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
              {activeModalClash.conflicts.map((conf, idx) => (
                <div key={idx} className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/80 text-xs">
                  <div className="font-semibold text-rose-900 dark:text-rose-200 flex items-center space-x-1.5 mb-1.5">
                    <span className="w-2 h-2 rounded-full bg-rose-500" />
                    <span>Resource Clash: {conf.reasons.join(', ')}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-700 dark:text-slate-300">
                    <div className="p-2 bg-white dark:bg-navy-900 rounded-lg border border-slate-200 dark:border-slate-800">
                      <p className="font-bold">{conf.class1.name} ({conf.class1.id})</p>
                      <p className="text-slate-500">Teacher: {conf.class1.teacher}</p>
                      <p className="text-slate-500">Room: {conf.class1.room}</p>
                      <p className="text-slate-500">Group: {conf.class1.group}</p>
                    </div>
                    <div className="p-2 bg-white dark:bg-navy-900 rounded-lg border border-slate-200 dark:border-slate-800">
                      <p className="font-bold">{conf.class2.name} ({conf.class2.id})</p>
                      <p className="text-slate-500">Teacher: {conf.class2.teacher}</p>
                      <p className="text-slate-500">Room: {conf.class2.room}</p>
                      <p className="text-slate-500">Group: {conf.class2.group}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end">
              <button
                onClick={() => setActiveModalClash(null)}
                className="px-4 py-1.5 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 text-xs font-semibold"
              >
                Dismiss
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
