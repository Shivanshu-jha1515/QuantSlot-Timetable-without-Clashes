import React from 'react';
import { Sliders, RotateCcw, Cpu, HelpCircle, Layers } from 'lucide-react';

export default function WeightsSliders({
  weights,
  setWeights,
  slots,
  setSlots,
  reads,
  setReads,
  solverMode,
  setSolverMode,
  onReset
}) {
  return (
    <div className="rounded-2xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 p-5 shadow-sm space-y-5 transition-colors">
      <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center space-x-2">
          <Sliders className="w-4 h-4 text-cyan-500" />
          <h4 className="font-bold text-slate-900 dark:text-white text-sm sm:text-base">
            QUBO Objective Parameters
          </h4>
        </div>
        <button
          onClick={onReset}
          className="flex items-center space-x-1 text-xs text-slate-500 dark:text-slate-400 hover:text-cyan-600 dark:hover:text-cyan-400 transition-colors"
          title="Reset to recommended defaults"
        >
          <RotateCcw className="w-3 h-3" />
          <span>Reset Defaults</span>
        </button>
      </div>

      <div className="space-y-4 text-xs">
        {/* Weight A: H1 Single slot per class */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="font-semibold text-slate-700 dark:text-slate-200 flex items-center space-x-1">
              <span>H₁ Weight (One Slot / Class)</span>
              <span className="text-[10px] text-cyan-600 dark:text-cyan-400 font-mono font-bold">W_A</span>
            </label>
            <span className="font-mono font-bold px-2 py-0.5 rounded bg-slate-100 dark:bg-navy-950 text-slate-800 dark:text-slate-200">
              {weights.A.toFixed(1)}
            </span>
          </div>
          <input
            type="range"
            min="1"
            max="30"
            step="0.5"
            value={weights.A}
            onChange={(e) => setWeights({ ...weights, A: parseFloat(e.target.value) })}
            className="w-full accent-cyan-500 h-1.5 bg-slate-200 dark:bg-navy-950 rounded-lg cursor-pointer"
          />
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
            Enforces that every lecture is scheduled exactly once: (∑ x_{'{c,s}'} - 1)²
          </p>
        </div>

        {/* Weight B: H2 No resource clashes */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="font-semibold text-slate-700 dark:text-slate-200 flex items-center space-x-1">
              <span>H₂ Weight (Clash Penalty)</span>
              <span className="text-[10px] text-teal-600 dark:text-teal-400 font-mono font-bold">W_B</span>
            </label>
            <span className="font-mono font-bold px-2 py-0.5 rounded bg-teal-100 dark:bg-teal-950/80 text-teal-800 dark:text-teal-300">
              {weights.B.toFixed(1)}
            </span>
          </div>
          <input
            type="range"
            min="1"
            max="40"
            step="0.5"
            value={weights.B}
            onChange={(e) => setWeights({ ...weights, B: parseFloat(e.target.value) })}
            className="w-full accent-teal-500 h-1.5 bg-slate-200 dark:bg-navy-950 rounded-lg cursor-pointer"
          />
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
            Heavy quadratic penalty for simultaneous teacher, room, or student group overlap.
          </p>
        </div>

        {/* Weight C: H3 Soft slot preferences */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="font-semibold text-slate-700 dark:text-slate-200 flex items-center space-x-1">
              <span>H₃ Weight (Soft Preferences)</span>
              <span className="text-[10px] text-amber-600 dark:text-amber-400 font-mono font-bold">W_C</span>
            </label>
            <span className="font-mono font-bold px-2 py-0.5 rounded bg-slate-100 dark:bg-navy-950 text-slate-800 dark:text-slate-200">
              {weights.C.toFixed(1)}
            </span>
          </div>
          <input
            type="range"
            min="0"
            max="10"
            step="0.2"
            value={weights.C}
            onChange={(e) => setWeights({ ...weights, C: parseFloat(e.target.value) })}
            className="w-full accent-amber-500 h-1.5 bg-slate-200 dark:bg-navy-950 rounded-lg cursor-pointer"
          />
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
            Smooths schedule distribution and prioritizes favorable time slots.
          </p>
        </div>

        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 grid grid-cols-2 gap-3">
          {/* Slots count */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="font-semibold text-slate-700 dark:text-slate-300">Slots Count</span>
              <span className="font-mono font-bold">{slots}</span>
            </div>
            <input
              type="range"
              min="8"
              max="24"
              step="1"
              value={slots}
              onChange={(e) => setSlots(parseInt(e.target.value))}
              className="w-full accent-indigo-500 h-1.5 bg-slate-200 dark:bg-navy-950 rounded-lg cursor-pointer"
            />
            <span className="text-[10px] text-slate-400">Total timetable periods</span>
          </div>

          {/* Reads count */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="font-semibold text-slate-700 dark:text-slate-300">Anneal Reads</span>
              <span className="font-mono font-bold">{reads}</span>
            </div>
            <input
              type="range"
              min="20"
              max="300"
              step="10"
              value={reads}
              onChange={(e) => setReads(parseInt(e.target.value))}
              className="w-full accent-cyan-500 h-1.5 bg-slate-200 dark:bg-navy-950 rounded-lg cursor-pointer"
            />
            <span className="text-[10px] text-slate-400">Monte Carlo trajectories</span>
          </div>
        </div>

        {/* Solver Mode selection */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
          <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
            Solver Engine
          </label>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setSolverMode('auto')}
              className={`p-2 rounded-xl text-left border text-[11px] transition-all ${
                solverMode === 'auto'
                  ? 'border-cyan-500 bg-cyan-50/60 dark:bg-cyan-950/40 text-cyan-900 dark:text-cyan-200 font-semibold'
                  : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center space-x-1">
                <Cpu className="w-3 h-3 text-cyan-500" />
                <span>Auto (dimod / D-Wave)</span>
              </div>
              <span className="text-[10px] opacity-75 font-normal block mt-0.5">dimod + dwave-neal</span>
            </button>

            <button
              type="button"
              onClick={() => setSolverMode('pure-python')}
              className={`p-2 rounded-xl text-left border text-[11px] transition-all ${
                solverMode === 'pure-python'
                  ? 'border-teal-500 bg-teal-50/60 dark:bg-teal-950/40 text-teal-900 dark:text-teal-200 font-semibold'
                  : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center space-x-1">
                <Sliders className="w-3 h-3 text-teal-500" />
                <span>Pure Python Annealer</span>
              </div>
              <span className="text-[10px] opacity-75 font-normal block mt-0.5">Ultra-fast zero-dep solver</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
