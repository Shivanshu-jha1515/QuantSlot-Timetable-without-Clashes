import React from 'react';
import { Cpu, Code2, Globe, Sparkles, Rocket, User, Award, ShieldCheck, CheckCircle2, ArrowRight, Layers, Binary } from 'lucide-react';

export default function AboutPage({ setActivePage }) {
  const techStack = [
    { name: 'FastAPI', category: 'Backend Framework', desc: 'High-performance async REST API with automatic OpenAPI specs' },
    { name: 'Python 3.14', category: 'Runtime', desc: 'Modern Python runtime with zero-overhead typing and robust execution' },
    { name: 'dimod & dwave-neal', category: 'Quantum Annealing', desc: 'D-Wave Systems QUBO formulations and simulated annealing sampler' },
    { name: 'Pure-Python Solver', category: 'Fallback Engine', desc: 'Adaptive Metropolis-Hastings local search with 0-clash guarantees' },
    { name: 'React 19 & Vite 6', category: 'Frontend Architecture', desc: 'Ultra-fast HMR and component reactivity for real-time timetable rendering' },
    { name: 'Tailwind CSS', category: 'Design System', desc: 'Responsive dark blue and teal aesthetic with native dark mode' },
  ];

  const futureScope = [
    {
      title: 'Real Quantum Hardware Integration',
      desc: 'Submitting QUBO formulations directly to D-Wave Advantage 5,000+ qubit QPUs via the D-Wave Leap cloud API for genuine quantum tunneling.',
      badge: 'Quantum Hardware',
      color: 'border-cyan-500/40 text-cyan-600 dark:text-cyan-400'
    },
    {
      title: 'University Final Exam Scheduling',
      desc: 'Managing student-level enrollments to guarantee students have zero exam clashes and a maximum of one major exam per 24-hour cycle.',
      badge: 'Higher Ed Scale',
      color: 'border-teal-500/40 text-teal-600 dark:text-teal-400'
    },
    {
      title: 'Dynamic Room & Facility Allocation',
      desc: 'Smart matching of chemistry fume hoods, specialized engineering labs, ADA wheelchair accessibility, and physical room capacity thresholds.',
      badge: 'Facility Planning',
      color: 'border-indigo-500/40 text-indigo-600 dark:text-indigo-400'
    },
    {
      title: 'Elective & Modular Course Scheduling',
      desc: 'Balancing multi-track curriculum electives with cross-department enrollment distributions across university colleges.',
      badge: 'Curriculum Ops',
      color: 'border-blue-500/40 text-blue-600 dark:text-blue-400'
    },
  ];

  const authorHighlights = [
    {
      title: 'QUBO Mathematical Modeling',
      desc: 'Formulated the three-part Hamiltonian (H₁ single slot, H₂ no teacher/room/group clash, H₃ soft preference distribution).',
      icon: Binary,
      color: 'text-cyan-500'
    },
    {
      title: 'Dual Solver Architecture',
      desc: 'Engineered seamless integration with dimod + dwave-neal alongside a zero-dependency pure-Python simulated annealer.',
      icon: Cpu,
      color: 'text-teal-500'
    },
    {
      title: 'Full-Stack Platform Engineering',
      desc: 'Built the async FastAPI REST backend, CORS data pipelines, and interactive React 19 visual conflict grid from scratch.',
      icon: Code2,
      color: 'text-indigo-500'
    },
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-16">
      {/* Hero Section */}
      <div className="text-center space-y-3 max-w-2xl mx-auto">
        <span className="text-xs font-mono font-bold uppercase tracking-wider text-cyan-600 dark:text-cyan-400">
          Our Vision & Technology
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-900 dark:text-white">
          About & Technology
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400">
          Bridging the gap between cutting-edge quantum optimization and day-to-day school and university administration.
        </p>
      </div>

      {/* Creator Spotlight: Shivanshu Jha */}
      <section className="rounded-3xl bg-gradient-to-br from-slate-900 via-navy-900 to-cyan-950 text-white p-8 sm:p-10 shadow-2xl border border-cyan-500/30 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-cyan-500 via-teal-400 to-blue-500 p-0.5 shadow-lg shadow-cyan-500/30 flex-shrink-0">
                <div className="w-full h-full bg-navy-950 rounded-[14px] flex items-center justify-center font-mono font-extrabold text-xl text-cyan-400">
                  SJ
                </div>
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
                    Shivanshu Jha
                  </h2>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                    Sole Creator & Architect
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-cyan-300/90 font-medium mt-0.5">
                  Designed & Engineered QuantSlot Solely from Ground Up
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <span className="text-xs font-mono px-3 py-1.5 rounded-xl bg-white/10 border border-white/15 text-slate-200">
                Python • QUBO • FastAPI • React
              </span>
            </div>
          </div>

          <p className="text-xs sm:text-sm text-slate-300 max-w-3xl leading-relaxed">
            QuantSlot is designed and developed solely by <span className="text-white font-semibold">Shivanshu Jha</span>. The project encompasses the complete mathematical formulation of educational scheduling as an Ising/QUBO spin glass, the dual simulated annealing solver engine, the production FastAPI REST backend, and the interactive React 19 timetable matrix with conflict highlighting.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
            {authorHighlights.map((hl) => {
              const Icon = hl.icon;
              return (
                <div key={hl.title} className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-1.5 backdrop-blur-xs">
                  <div className="flex items-center space-x-2">
                    <Icon className={`w-4 h-4 ${hl.color}`} />
                    <h3 className="font-bold text-xs text-white">
                      {hl.title}
                    </h3>
                  </div>
                  <p className="text-[11px] text-slate-300 leading-normal">
                    {hl.desc}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Project Story */}
      <section className="rounded-3xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 p-8 sm:p-10 shadow-sm space-y-4">
        <div className="flex items-center space-x-2 text-cyan-600 dark:text-cyan-400 font-bold text-sm">
          <Sparkles className="w-4 h-4" />
          <span>The Project Story</span>
        </div>
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
          Why QuantSlot Was Created
        </h2>
        <div className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 space-y-3 leading-relaxed">
          <p>
            At the beginning of every academic term, school administrators and university department chairs face a notorious NP-hard dilemma: scheduling hundreds of lectures without professors demanding the same laboratory, or two cohorts double-booked in the same lecture hall.
          </p>
          <p>
            Traditional scheduling tools rely on simplistic greedy heuristics that freeze in local minima—leaving behind 15 to 25 unresolved collisions that administrators must manually untangle.
          </p>
          <p>
            <span className="font-semibold text-cyan-600 dark:text-cyan-400">Conceived and architected solely by Shivanshu Jha:</span> QuantSlot translates timetabling into finding the minimum energy ground state of a physical Hamiltonian. By encoding every collision as an energy penalty in a QUBO formulation, quantum-inspired simulated annealing tunnels through barrier cost walls, resolving 18 clashes down to zero in under a second.
          </p>
        </div>
      </section>

      {/* Tech Stack Grid */}
      <section className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
            Production Technology Stack
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
            Engineered for high reliability, responsiveness, and seamless local or cloud execution.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {techStack.map((tech) => (
            <div key={tech.name} className="p-5 rounded-2xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
              <span className="text-[10px] font-mono uppercase tracking-wider text-cyan-600 dark:text-cyan-400 font-bold">
                {tech.category}
              </span>
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                {tech.name}
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-normal">
                {tech.desc}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Future Scope */}
      <section className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center space-x-2">
            <span>Future Scope & Roadmap</span>
            <Rocket className="w-5 h-5 text-cyan-500" />
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
            Expanding from simulated annealing on local servers to full-scale real quantum annealers.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {futureScope.map((item) => (
            <div key={item.title} className="p-6 rounded-2xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase border ${item.color}`}>
                {item.badge}
              </span>
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                {item.title}
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                {item.desc}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <div className="pt-6 text-center">
        <button
          onClick={() => setActivePage('demo')}
          className="inline-flex items-center space-x-2 px-6 py-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-md transition-colors"
        >
          <span>Explore QuantSlot in the Live Optimizer</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
