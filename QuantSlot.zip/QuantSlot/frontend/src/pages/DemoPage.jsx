import React, { useState, useEffect, useRef } from 'react';
import { Upload, Sparkles, RefreshCw, Play, AlertCircle, CheckCircle, FileText, Download, Layers } from 'lucide-react';
import ClassTable from '../components/ClassTable';
import WeightsSliders from '../components/WeightsSliders';
import TimetableGrid from '../components/TimetableGrid';
import ResultsCounter from '../components/ResultsCounter';
import { TimetableSkeleton, MetricSkeleton } from '../components/SkeletonLoader';
import { fetchSampleData, uploadCSVFile, runOptimizer, downloadCSV } from '../services/api';

export default function DemoPage() {
  const [classes, setClasses] = useState([]);
  const [slots, setSlots] = useState(12);
  const [weights, setWeights] = useState({ A: 10.0, B: 15.0, C: 1.0 });
  const [reads, setReads] = useState(100);
  const [solverMode, setSolverMode] = useState('auto'); // 'auto' or 'pure-python'

  // Solver states
  const [isLoading, setIsLoading] = useState(false);
  const [isDataLoading, setIsDataLoading] = useState(true);
  const [optimizationResult, setOptimizationResult] = useState(null);
  const [baselineAssignment, setBaselineAssignment] = useState([]);
  const [errorMessage, setErrorMessage] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);

  const fileInputRef = useRef(null);

  // Load sample dataset on mount
  useEffect(() => {
    loadSample();
  }, []);

  const loadSample = async () => {
    setIsDataLoading(true);
    setErrorMessage(null);
    try {
      const data = await fetchSampleData();
      setClasses(data.classes || []);
      setSlots(data.slots || 12);
      if (data.weights) setWeights(data.weights);
      if (data.reads) setReads(data.reads);

      // Auto-run optimizer initially to give an immediate polished view
      await triggerOptimize(data.classes, data.slots || 12, data.weights, data.reads);
      setSuccessMessage('Loaded 30 benchmark classes across 12 time slots.');
    } catch (err) {
      console.warn('API load failed, falling back to local benchmark dataset:', err);
      // Fallback local dataset if backend is booting
      const fallbackClasses = [
        { id: "CS101", name: "Intro to Programming", teacher: "Dr. Alan Turing", group: "CS-Year1", room: "Room-101" },
        { id: "CS102", name: "Data Structures", teacher: "Prof. John von Neumann", group: "CS-Year1", room: "Room-101" },
        { id: "CS103", name: "Discrete Math", teacher: "Dr. Alan Turing", group: "CS-Year1", room: "Room-102" },
        { id: "CS201", name: "Algorithms", teacher: "Prof. John von Neumann", group: "CS-Year2", room: "Lab-201" },
        { id: "CS202", name: "Operating Systems", teacher: "Prof. Ada Lovelace", group: "CS-Year2", room: "Lab-201" },
        { id: "CS203", name: "Database Systems", teacher: "Prof. Ada Lovelace", group: "CS-Year2", room: "Room-102" },
        { id: "PH101", name: "Classical Mechanics", teacher: "Prof. Marie Curie", group: "Physics-Year1", room: "Room-101" },
        { id: "PH102", name: "Electromagnetism", teacher: "Prof. Marie Curie", group: "Physics-Year1", room: "Room-102" },
        { id: "PH103", name: "Quantum Foundations", teacher: "Dr. Richard Feynman", group: "Physics-Year1", room: "Lab-202" },
        { id: "PH201", name: "Statistical Mechanics", teacher: "Dr. Richard Feynman", group: "Physics-Year1", room: "Room-102" },
        { id: "MA101", name: "Calculus I", teacher: "Prof. Emmy Noether", group: "Math-Year1", room: "Room-101" },
        { id: "MA102", name: "Linear Algebra", teacher: "Prof. Emmy Noether", group: "Math-Year1", room: "Room-102" },
        { id: "MA103", name: "Probability & Stats", teacher: "Dr. Claude Shannon", group: "Math-Year1", room: "Seminar-301" },
        { id: "DS101", name: "Intro to Data Science", teacher: "Dr. Claude Shannon", group: "DataScience-Year2", room: "Lab-201" },
        { id: "DS102", name: "Machine Learning", teacher: "Prof. Ada Lovelace", group: "DataScience-Year2", room: "Lab-201" },
        { id: "DS103", name: "Big Data Analytics", teacher: "Prof. John von Neumann", group: "DataScience-Year2", room: "Lab-201" },
        { id: "BIO101", name: "Molecular Biology", teacher: "Dr. Rosalind Franklin", group: "Bio-Year1", room: "Room-101" },
        { id: "BIO102", name: "Genetics", teacher: "Dr. Rosalind Franklin", group: "Bio-Year1", room: "Lab-202" },
        { id: "BIO103", name: "Bio-Chemistry", teacher: "Prof. Marie Curie", group: "Bio-Year1", room: "Lab-202" },
        { id: "CH101", name: "General Chemistry", teacher: "Prof. Marie Curie", group: "Bio-Year1", room: "Room-102" },
        { id: "CS301", name: "Compiler Design", teacher: "Prof. Ada Lovelace", group: "CS-Year2", room: "Room-101" },
        { id: "CS302", name: "Computer Networks", teacher: "Dr. Claude Shannon", group: "CS-Year2", room: "Lab-201" },
        { id: "PH301", name: "Particle Physics", teacher: "Dr. Richard Feynman", group: "Physics-Year1", room: "Seminar-301" },
        { id: "MA201", name: "Abstract Algebra", teacher: "Prof. Emmy Noether", group: "Math-Year1", room: "Seminar-301" },
        { id: "MA202", name: "Complex Analysis", teacher: "Prof. Emmy Noether", group: "Math-Year1", room: "Room-102" },
        { id: "CS104", name: "Digital Logic", teacher: "Dr. Alan Turing", group: "CS-Year1", room: "Lab-201" },
        { id: "CS105", name: "Web Development", teacher: "Prof. Ada Lovelace", group: "CS-Year1", room: "Lab-201" },
        { id: "DS201", name: "Information Theory", teacher: "Dr. Claude Shannon", group: "DataScience-Year2", room: "Seminar-301" },
        { id: "PH104", name: "Modern Physics Lab", teacher: "Dr. Richard Feynman", group: "Physics-Year1", room: "Lab-202" },
        { id: "BIO201", name: "Structural Genomics", teacher: "Dr. Rosalind Franklin", group: "Bio-Year1", room: "Lab-202" }
      ];
      setClasses(fallbackClasses);
      setSlots(12);
      await triggerOptimize(fallbackClasses, 12, { A: 10.0, B: 15.0, C: 1.0 }, 100);
      setSuccessMessage('Loaded 30 benchmark classes.');
    } finally {
      setIsDataLoading(false);
    }
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsLoading(true);
    setErrorMessage(null);
    try {
      const data = await uploadCSVFile(file);
      setClasses(data.classes || []);
      setSuccessMessage(`Successfully uploaded ${data.count} classes from ${file.name}`);
      // Clear file input
      if (fileInputRef.current) fileInputRef.current.value = '';
      // Trigger optimize on new data
      await triggerOptimize(data.classes, slots, weights, reads);
    } catch (err) {
      setErrorMessage(err.message || 'Failed to upload CSV file');
    } finally {
      setIsLoading(false);
    }
  };

  const triggerOptimize = async (customClasses = null, customSlots = null, customWeights = null, customReads = null) => {
    const clsToSolve = customClasses || classes;
    const currentSlots = customSlots || slots;
    const currentWeights = customWeights || weights;
    const currentReads = customReads || reads;

    if (!clsToSolve || clsToSolve.length === 0) {
      setErrorMessage('Please add or load at least one class to optimize.');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    try {
      const result = await runOptimizer({
        classes: clsToSolve,
        slots: currentSlots,
        weights: currentWeights,
        reads: currentReads,
        force_solver: solverMode === 'pure-python' ? 'pure-python' : undefined
      });

      setOptimizationResult(result);

      // Create a matching baseline assignment for the 'Before' view
      // Naively round robin packed
      const baseline = clsToSolve.map((c, idx) => ({
        ...c,
        slot: idx % Math.max(1, Math.min(currentSlots, 6))
      }));
      setBaselineAssignment(baseline);

      if (result.clashes_after === 0) {
        setSuccessMessage(`Ground state achieved! Solved in ${result.solve_time_ms} ms with 0 clashes.`);
      } else {
        setSuccessMessage(`Optimization complete: reduced from ${result.clashes_before} to ${result.clashes_after} clashes.`);
      }
    } catch (err) {
      setErrorMessage(err.message || 'Optimization request failed. Ensure backend is running.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleResetWeights = () => {
    setWeights({ A: 10.0, B: 15.0, C: 1.0 });
    setSlots(12);
    setReads(100);
    setSolverMode('auto');
    setSuccessMessage('QUBO weights and parameters reset to standard defaults.');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Banner & Action Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <span className="p-1 rounded-lg bg-cyan-600 text-white">
              <Sparkles className="w-4 h-4" />
            </span>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">
              Interactive Timetable Optimizer
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
            Formulate resource constraints into a QUBO Hamiltonian matrix and anneal to zero clashes.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Hidden File Input */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept=".csv"
            className="hidden"
          />

          {/* Upload CSV */}
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center space-x-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-navy-800 shadow-xs transition-colors"
          >
            <Upload className="w-3.5 h-3.5 text-cyan-500" />
            <span>Upload CSV</span>
          </button>

          {/* Load Sample Data */}
          <button
            onClick={loadSample}
            disabled={isDataLoading}
            className="flex items-center space-x-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-navy-800 shadow-xs transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-teal-500 ${isDataLoading ? 'animate-spin' : ''}`} />
            <span>Load Sample (30 Classes)</span>
          </button>

          {/* Run Optimizer */}
          <button
            onClick={() => triggerOptimize()}
            disabled={isLoading || classes.length === 0}
            className="flex items-center space-x-2 px-5 py-2 text-xs font-bold rounded-xl bg-gradient-to-r from-cyan-600 to-teal-600 hover:from-cyan-500 hover:to-teal-500 text-white shadow-md shadow-cyan-600/25 transition-all hover:scale-[1.02] disabled:opacity-50"
          >
            {isLoading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Annealing QUBO...</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>Run Optimizer</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Notifications / Alerts */}
      {errorMessage && (
        <div className="p-4 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900/60 text-xs text-rose-800 dark:text-rose-200 flex items-start justify-between shadow-xs">
          <div className="flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 flex-shrink-0" />
            <span>{errorMessage}</span>
          </div>
          <button onClick={() => setErrorMessage(null)} className="font-bold ml-2">✕</button>
        </div>
      )}

      {successMessage && (
        <div className="p-3.5 rounded-xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-900/60 text-xs text-teal-800 dark:text-teal-200 flex items-center justify-between shadow-xs">
          <div className="flex items-center space-x-2">
            <CheckCircle className="w-4 h-4 text-teal-600 dark:text-teal-400 flex-shrink-0" />
            <span>{successMessage}</span>
          </div>
          <button onClick={() => setSuccessMessage(null)} className="font-bold ml-2">✕</button>
        </div>
      )}

      {/* Metric Cards (Before vs After, Solve Time, QUBO Variables) */}
      {isLoading ? (
        <MetricSkeleton />
      ) : optimizationResult ? (
        <ResultsCounter
          before={optimizationResult.clashes_before}
          after={optimizationResult.clashes_after}
          solveTime={optimizationResult.solve_time_ms}
          solver={optimizationResult.solver_used}
          quboVars={optimizationResult.qubo_vars}
        />
      ) : null}

      {/* Main Grid & Setup Section */}
      {classes.length === 0 ? (
        /* Empty State */
        <div className="p-12 text-center rounded-2xl border-2 border-dashed border-slate-300 dark:border-slate-800 bg-white/40 dark:bg-navy-900/40 space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-cyan-100 dark:bg-cyan-950 text-cyan-600 dark:text-cyan-400 mx-auto flex items-center justify-center">
            <Layers className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-lg text-slate-800 dark:text-slate-200">
            No Classes in Schedule
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto">
            Get started by loading the 30-class college sample dataset or uploading your own CSV file.
          </p>
          <div className="flex items-center justify-center space-x-3 pt-2">
            <button
              onClick={loadSample}
              className="px-4 py-2 rounded-xl bg-cyan-600 text-white text-xs font-semibold shadow-sm hover:bg-cyan-500"
            >
              Load Sample Data
            </button>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-navy-800 text-slate-700 dark:text-slate-300 text-xs font-semibold hover:bg-slate-200"
            >
              Upload CSV
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-8">
          {/* Timetable Grid View */}
          {isLoading ? (
            <TimetableSkeleton slots={slots} />
          ) : optimizationResult ? (
            <TimetableGrid
              assignment={optimizationResult.assignment}
              baselineAssignment={baselineAssignment}
              slots={slots}
              clashesBefore={optimizationResult.clashes_before}
              clashesAfter={optimizationResult.clashes_after}
              solveTime={optimizationResult.solve_time_ms}
              clashDetailsAfter={optimizationResult.clash_details_after || []}
              clashDetailsBefore={optimizationResult.clash_details_before || []}
            />
          ) : null}

          {/* Configuration & Class Input Panel */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1">
              <WeightsSliders
                weights={weights}
                setWeights={setWeights}
                slots={slots}
                setSlots={setSlots}
                reads={reads}
                setReads={setReads}
                solverMode={solverMode}
                setSolverMode={setSolverMode}
                onReset={handleResetWeights}
              />
            </div>

            <div className="lg:col-span-2">
              <ClassTable
                classes={classes}
                setClasses={setClasses}
                onResetSample={loadSample}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
