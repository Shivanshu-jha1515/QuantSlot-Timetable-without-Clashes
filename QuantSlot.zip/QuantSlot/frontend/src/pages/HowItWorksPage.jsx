import React from 'react';
import { Binary, Cpu, Layers, Zap, CheckCircle2, ShieldAlert, Sparkles, BookOpen, Atom } from 'lucide-react';
import AlgorithmDiagram from '../components/AlgorithmDiagram';

export default function HowItWorksPage({ setActivePage }) {
  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      {/* Header */}
      <div className="text-center space-y-3 max-w-2xl mx-auto">
        <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-cyan-50 dark:bg-cyan-950/80 border border-cyan-200 dark:border-cyan-800 text-cyan-700 dark:text-cyan-300 text-xs font-semibold">
          <Atom className="w-3.5 h-3.5 text-cyan-500" />
          <span>Physics-Based Optimization Math</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-900 dark:text-white">
          How QUBO Solves the Timetabling Problem
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400">
          From binary state variables to quantum annealing ground states. Learn how QuantSlot formulates complex scheduling constraints as an energy Hamiltonian.
        </p>
      </div>

      {/* Interactive Algorithmic Pipeline Diagram */}
      <AlgorithmDiagram />

      {/* Deep-dive 1: Binary Decision Variables */}
      <section className="rounded-2xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-8 space-y-4 shadow-sm">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-50 dark:bg-cyan-950 text-cyan-600 dark:text-cyan-400 flex items-center justify-center font-bold">
            <Binary className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">
              1. Binary Decision Variables: x(c, s)
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              The fundamental unit of information in the QUBO formulation.
            </p>
          </div>
        </div>

        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
          For any educational institution with <span className="font-semibold text-slate-800 dark:text-slate-200">C courses</span> and <span className="font-semibold text-slate-800 dark:text-slate-200">S available time slots</span>, we construct a binary matrix of decision variables <code className="font-mono text-cyan-600 dark:text-cyan-400">x(c, s) ∈ {'{0, 1}'}</code>:
        </p>

        <div className="p-4 rounded-xl bg-slate-50 dark:bg-navy-950 border border-slate-200 dark:border-slate-800 font-mono text-xs text-slate-800 dark:text-slate-200 space-y-1">
          <p className="text-cyan-600 dark:text-cyan-400 font-bold">// Binary assignment interpretation:</p>
          <p>x(c, s) = 1  ⟺  Course c is assigned to period slot s</p>
          <p>x(c, s) = 0  ⟺  Course c is NOT scheduled in slot s</p>
        </div>

        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
          For our benchmark scenario (30 classes and 12 slots), there are <span className="font-mono font-bold text-cyan-600 dark:text-cyan-400">30 × 12 = 360 binary variables</span>. The state space contains <span className="font-mono">2³⁶⁰ ≈ 2.3 × 10¹⁰⁸</span> possible binary vectors.
        </p>
      </section>

      {/* Deep-dive 2: The Three Objective Terms */}
      <section className="space-y-4">
        <div className="space-y-1">
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center space-x-2">
            <span>2. The Three Objective Terms: H = W_A·H₁ + W_B·H₂ + W_C·H₃</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Real-world constraints converted into mathematical energy penalties.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Term H1 */}
          <div className="p-6 rounded-2xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase bg-cyan-100 dark:bg-cyan-950 text-cyan-700 dark:text-cyan-300">
                Hard Constraint
              </span>
              <span className="text-xs font-mono font-bold text-cyan-500">W_A = 10.0</span>
            </div>
            <h3 className="font-bold text-slate-900 dark:text-white text-base">
              H₁: Exactly One Slot Per Class
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              Every class must appear exactly once in the timetable—neither omitted nor double-scheduled.
            </p>
            <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-navy-950 font-mono text-[11px] text-cyan-600 dark:text-cyan-400 border border-slate-200 dark:border-slate-800">
              H₁ = ∑_c ( ∑_s x_{'{c,s}'} - 1 )²
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-normal">
              Expanding the square yields diagonal terms -x_{'{c,s}'} and off-diagonal pairwise penalties +2·x_{'{c,s}'}·x_{'{c,s\'}'}.
            </p>
          </div>

          {/* Term H2 */}
          <div className="p-6 rounded-2xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-300">
                Hard Constraint
              </span>
              <span className="text-xs font-mono font-bold text-teal-500">W_B = 15.0</span>
            </div>
            <h3 className="font-bold text-slate-900 dark:text-white text-base">
              H₂: Zero Resource Clashes
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              Penalizes any simultaneous overlap of instructors, physical classrooms, or student cohorts.
            </p>
            <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-navy-950 font-mono text-[11px] text-teal-600 dark:text-teal-400 border border-slate-200 dark:border-slate-800">
              H₂ = ∑_{'{c1 < c2, s}'} K(c1, c2) · x_{'{c1,s}'} · x_{'{c2,s}'}
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-normal">
              K(c1, c2) counts shared resource dimensions: teacher overlap + room overlap + student group overlap.
            </p>
          </div>

          {/* Term H3 */}
          <div className="p-6 rounded-2xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300">
                Soft Constraint
              </span>
              <span className="text-xs font-mono font-bold text-amber-500">W_C = 1.0</span>
            </div>
            <h3 className="font-bold text-slate-900 dark:text-white text-base">
              H₃: Soft Slot Preferences
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              Guides scheduling toward balanced schedules, favorable morning slots, and teacher requests.
            </p>
            <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-navy-950 font-mono text-[11px] text-amber-600 dark:text-amber-400 border border-slate-200 dark:border-slate-800">
              H₃ = ∑_{'{c,s}'} P(c, s) · x_{'{c,s}'}
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-normal">
              Linear cost function adding subtle gradient favoring optimal pedagogical time distributions.
            </p>
          </div>
        </div>
      </section>

      {/* Combinatorial Comparison Table */}
      <section className="rounded-2xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm space-y-4">
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">
          Why Classical Search Freezes vs Quantum Annealing
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-200 dark:border-slate-800 font-mono text-slate-400 uppercase">
              <tr>
                <th className="py-2 px-3">Metric</th>
                <th className="py-2 px-3">Classical Brute Force</th>
                <th className="py-2 px-3">Greedy Hill-Climbing</th>
                <th className="py-2 px-3 text-cyan-600 dark:text-cyan-400 font-bold">QuantSlot (QUBO Annealing)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 text-slate-600 dark:text-slate-300">
              <tr>
                <td className="py-2.5 px-3 font-semibold">Combinations (30 classes, 12 slots)</td>
                <td className="py-2.5 px-3 font-mono">12³⁰ ≈ 2.37 × 10³²</td>
                <td className="py-2.5 px-3">Samples ~10³</td>
                <td className="py-2.5 px-3 font-mono font-bold text-cyan-600 dark:text-cyan-400">Explores thermal valley</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold">Local Minima Vulnerability</td>
                <td className="py-2.5 px-3">N/A (Times out)</td>
                <td className="py-2.5 px-3 text-rose-500">Stuck at 5–18 clashes</td>
                <td className="py-2.5 px-3 text-teal-500 font-bold">Tunnels out via thermal flips</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold">Execution Time</td>
                <td className="py-2.5 px-3 text-rose-500">Billions of years</td>
                <td className="py-2.5 px-3">15–60 seconds</td>
                <td className="py-2.5 px-3 text-teal-500 font-bold font-mono">4 to 818 milliseconds</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold">Hardware Scalability</td>
                <td className="py-2.5 px-3">None</td>
                <td className="py-2.5 px-3">CPU only</td>
                <td className="py-2.5 px-3 font-semibold text-cyan-600 dark:text-cyan-400">Native to D-Wave QPUs</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      {/* Bottom CTA */}
      <div className="p-8 rounded-2xl bg-gradient-to-r from-cyan-600 via-teal-600 to-blue-600 text-white text-center space-y-4 shadow-lg shadow-cyan-600/20">
        <h3 className="text-2xl font-bold">Experience the Math in Action</h3>
        <p className="text-xs sm:text-sm text-cyan-100 max-w-lg mx-auto">
          Test the live optimizer with the full 30-class college dataset or upload your own school courses.
        </p>
        <button
          onClick={() => setActivePage('demo')}
          className="px-6 py-3 rounded-xl bg-white text-cyan-900 font-bold text-xs hover:bg-cyan-50 shadow-md transition-colors"
        >
          Launch Demo Optimizer
        </button>
      </div>
    </div>
  );
}
