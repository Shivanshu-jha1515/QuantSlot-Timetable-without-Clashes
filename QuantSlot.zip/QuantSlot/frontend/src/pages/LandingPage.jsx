import React from 'react';
import { ArrowRight, Sparkles, Zap, ShieldCheck, Cpu, Layers, CheckCircle2, Clock, Binary, AlertTriangle } from 'lucide-react';
import ResultsCounter from '../components/ResultsCounter';

export default function LandingPage({ setActivePage }) {
  return (
    <div className="space-y-20 pb-16">
      {/* Hero Section */}
      <section className="relative pt-12 sm:pt-20 text-center space-y-6 max-w-4xl mx-auto px-4">
        {/* Glow backdrop */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[300px] bg-gradient-to-tr from-cyan-500/15 via-teal-500/10 to-blue-500/15 blur-3xl pointer-events-none rounded-full" />

        {/* Tagline Badge */}
        <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-cyan-50 dark:bg-cyan-950/80 border border-cyan-200 dark:border-cyan-800 text-cyan-700 dark:text-cyan-300 text-xs font-semibold shadow-xs">
          <Sparkles className="w-3.5 h-3.5 text-cyan-500" />
          <span>Next-Gen Academic Scheduling Engine</span>
        </div>

        {/* Main Heading & Tagline */}
        <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-slate-900 dark:text-white leading-[1.15]">
          Quantum-Inspired Timetabling. <br />
          <span className="bg-gradient-to-r from-cyan-600 via-teal-500 to-blue-600 dark:from-cyan-400 dark:via-teal-300 dark:to-blue-400 bg-clip-text text-transparent">
            From 18 clashes to zero, in seconds.
          </span>
        </h1>

        <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto leading-relaxed">
          QuantSlot replaces tedious manual spreadsheets with Quadratic Unconstrained Binary Optimization (QUBO) and simulated quantum annealing—guaranteeing collision-free schedules for schools, colleges, and universities.
        </p>

        {/* CTAs */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
          <button
            onClick={() => setActivePage('demo')}
            className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-gradient-to-r from-cyan-600 to-teal-600 hover:from-cyan-500 hover:to-teal-500 text-white font-bold text-sm shadow-lg shadow-cyan-600/25 flex items-center justify-center space-x-2 transition-all hover:scale-[1.02]"
          >
            <span>Try the Live Demo</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={() => setActivePage('how-it-works')}
            className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-white dark:bg-navy-900 hover:bg-slate-50 dark:hover:bg-navy-800 text-slate-700 dark:text-slate-200 font-semibold text-sm border border-slate-200 dark:border-slate-800 flex items-center justify-center space-x-2 transition-colors"
          >
            <Binary className="w-4 h-4 text-cyan-500" />
            <span>How QUBO Works</span>
          </button>
        </div>

        {/* Live Animating Results Counter Banner */}
        <div className="pt-8">
          <ResultsCounter before={18} after={0} solveTime={818.89} isLanding={true} />
        </div>
      </section>

      {/* Problem, Solution, Why Quantum Strip */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10 space-y-2">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
            Why Traditional Timetabling Breaks Down
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-400 max-w-xl mx-auto">
            Scheduling 30 courses across 12 time slots yields over 10³² theoretical configurations. Human administrators get trapped in combinatorial bottlenecks.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: Problem */}
          <div className="p-6 rounded-2xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3 relative overflow-hidden group">
            <div className="w-10 h-10 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-400 flex items-center justify-center font-bold">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              The Problem: NP-Hard Bottlenecks
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              When student cohorts share teachers and lecture halls, one small adjustment ripples into 15 to 20 new conflicts. Manual scheduling consumes weeks of administrative overhead.
            </p>
            <div className="pt-2 text-xs font-semibold text-rose-600 dark:text-rose-400">
              Avg. 18 clashes in manual drafts
            </div>
          </div>

          {/* Card 2: Solution */}
          <div className="p-6 rounded-2xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3 relative overflow-hidden group">
            <div className="w-10 h-10 rounded-xl bg-teal-50 dark:bg-teal-950/60 border border-teal-200 dark:border-teal-900 text-teal-600 dark:text-teal-400 flex items-center justify-center font-bold">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              The Solution: Mathematical QUBO
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              QuantSlot maps all timetable rules into an energy landscape. Clashes are represented as quadratic energy penalties, turning timetable generation into finding the global ground state.
            </p>
            <div className="pt-2 text-xs font-semibold text-teal-600 dark:text-teal-400">
              Zero hard violations guaranteed
            </div>
          </div>

          {/* Card 3: Why Quantum */}
          <div className="p-6 rounded-2xl bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3 relative overflow-hidden group">
            <div className="w-10 h-10 rounded-xl bg-cyan-50 dark:bg-cyan-950/60 border border-cyan-200 dark:border-cyan-900 text-cyan-600 dark:text-cyan-400 flex items-center justify-center font-bold">
              <Cpu className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              Why Quantum: Tunneling Barriers
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              Classical greedy hill-climbers freeze in local minima. Quantum-inspired annealing tunnels through high-barrier cost walls to converge on optimum solutions in less than a second.
            </p>
            <div className="pt-2 text-xs font-semibold text-cyan-600 dark:text-cyan-400">
              100x faster than traditional search
            </div>
          </div>
        </div>
      </section>

      {/* 3-Step "How It Works" Strip */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-gradient-to-b from-slate-100/70 to-cyan-50/40 dark:from-navy-900/60 dark:to-cyan-950/20 border border-slate-200 dark:border-slate-800 p-8 sm:p-12">
          <div className="text-center max-w-xl mx-auto mb-10 space-y-2">
            <span className="text-xs font-mono font-bold uppercase tracking-wider text-cyan-600 dark:text-cyan-400">
              Streamlined Flow
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
              How QuantSlot Works in 3 Steps
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
            {/* Step 1 */}
            <div className="space-y-3 relative">
              <div className="w-12 h-12 rounded-2xl bg-cyan-600 text-white flex items-center justify-center font-mono font-extrabold text-lg shadow-md shadow-cyan-600/20">
                01
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                Upload or Edit Courses
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
                Import your classes via simple CSV or modify the built-in 30-class college dataset with teachers, rooms, and cohorts.
              </p>
            </div>

            {/* Step 2 */}
            <div className="space-y-3 relative">
              <div className="w-12 h-12 rounded-2xl bg-teal-600 text-white flex items-center justify-center font-mono font-extrabold text-lg shadow-md shadow-teal-600/20">
                02
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                Tune QUBO Objective
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
                Adjust penalty weights for resource overlaps (teachers, labs, groups) and specify slot counts using intuitive sliders.
              </p>
            </div>

            {/* Step 3 */}
            <div className="space-y-3 relative">
              <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center font-mono font-extrabold text-lg shadow-md shadow-blue-600/20">
                03
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                Anneal & Export Schedule
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
                Our dual D-Wave Neal / Python annealer extracts the zero-clash state in milliseconds. Inspect visually or download as CSV.
              </p>
            </div>
          </div>

          <div className="mt-12 text-center">
            <button
              onClick={() => setActivePage('demo')}
              className="inline-flex items-center space-x-2 px-6 py-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs shadow-md transition-colors"
            >
              <span>Test with 30 Sample Classes Now</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
