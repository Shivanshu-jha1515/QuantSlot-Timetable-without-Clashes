/**
 * api.js - Communication layer for QuantSlot backend
 */

const API_BASE = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000';

export async function fetchHealth() {
  try {
    const res = await fetch(`${API_BASE}/api/health`);
    if (!res.ok) throw new Error(`Health check failed: ${res.statusText}`);
    return await res.json();
  } catch (err) {
    console.warn('Backend offline or unreachable:', err);
    return { status: 'offline', error: err.message };
  }
}

export async function fetchSampleData() {
  const res = await fetch(`${API_BASE}/api/sample`);
  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.detail || `Failed to fetch sample data (${res.status})`);
  }
  return await res.json();
}

export async function uploadCSVFile(file) {
  const formData = new FormData();
  formData.append('file', file);

  const res = await fetch(`${API_BASE}/api/upload`, {
    method: 'POST',
    body: formData,
  });

  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.detail || `Failed to upload CSV (${res.status})`);
  }
  return await res.json();
}

export async function runOptimizer({ classes, slots, weights, reads, force_solver }) {
  const payload = {
    classes,
    slots: Number(slots),
    weights: {
      A: Number(weights.A),
      B: Number(weights.B),
      C: Number(weights.C),
    },
    reads: Number(reads) || 100,
    force_solver: force_solver || undefined,
  };

  const res = await fetch(`${API_BASE}/api/optimize`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.detail || `Optimization failed with status ${res.status}`);
  }

  return await res.json();
}

/**
 * Downloads assigned classes as a structured timetable CSV
 */
export function downloadCSV(assignment, slots, filename = 'quant_slot_optimized_timetable.csv') {
  if (!assignment || assignment.length === 0) return;

  const headers = ['Class ID', 'Course Name', 'Teacher', 'Student Group', 'Room', 'Slot Number', 'Day', 'Period'];
  
  // Calculate periods per day based on slot count
  const periodsPerDay = slots <= 12 ? 4 : 5;
  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  const rows = assignment.map((cls) => {
    const slotNum = cls.slot != null ? cls.slot : -1;
    const dayIndex = slotNum >= 0 ? Math.floor(slotNum / periodsPerDay) % days.length : 0;
    const periodIndex = slotNum >= 0 ? (slotNum % periodsPerDay) + 1 : 0;
    const dayName = slotNum >= 0 ? days[dayIndex] : 'Unassigned';

    return [
      `"${cls.id || ''}"`,
      `"${cls.name || ''}"`,
      `"${cls.teacher || ''}"`,
      `"${cls.group || ''}"`,
      `"${cls.room || ''}"`,
      slotNum,
      `"${dayName}"`,
      periodIndex > 0 ? `Period ${periodIndex}` : 'None'
    ].join(',');
  });

  const csvContent = [headers.join(','), ...rows].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
